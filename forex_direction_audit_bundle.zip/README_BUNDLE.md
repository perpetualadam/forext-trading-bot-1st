# Forex directional decision audit bundle

Safe source-only bundle for external review of the bot's BUY/SELL/SKIP path.

This archive contains production source, focused tests, and the V2 shadow
framework document. It does **not** contain `.env`, credentials, logs, trade
data, databases, historical market CSVs, shadow JSONL, or git history.

## How to read the decision path

1. `forex_bot/app.py` — process start; `run_bot` task
2. `forex_bot/bot_loop.py` — `evaluate()` cycle
3. `forex_bot/strategy_meta.py` — strategy **label** (not side)
4. `forex_bot/ai_ensemble.py` — LocalLLM / `_quant_stub_vote` + optional API voters
5. `forex_bot/nn_pred.py` — nn/seq features passed into the ensemble payload
6. `forex_bot/rl_agent.py` — SKIP / same-side gate
7. `forex_bot/v2_shadow/` — observe-only hook; return discarded
8. `forex_bot/execution.py` + `orders.py` + `oanda_exec.py` — authorization / OrderCreate boundary

See `forex_bot/decision_quality/live_path.py` and
`reports/decision_quality/v2_shadow_framework.md`.
