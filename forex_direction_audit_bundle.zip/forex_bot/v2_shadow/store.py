"""Append-only research JSONL. Separate from production trade rows. No DB migration."""

from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from forex_bot.v2_shadow.contract import ShadowOutcome, V2ShadowDecision

_DEFAULT_DIR = Path(__file__).resolve().parents[2] / "data" / "research" / "v2_shadow"
OBS_NAME = "observations.jsonl"
OUT_NAME = "outcomes.jsonl"
DEFAULT_ARCHIVE_BYTES = 50 * 1024 * 1024

# Keys that must never appear in research JSONL (defense in depth).
_SECRET_SUBSTR = (
    "api_key",
    "access_token",
    "bot_token",
    "password",
    "secret",
    "authorization",
    "oanda_token",
    "telegram_token",
    "webhook",
    "bearer",
)


def default_store_dir(root: Path | None = None) -> Path:
    if root is None:
        return _DEFAULT_DIR
    return Path(root) / "data" / "research" / "v2_shadow"


def observations_path(store_dir: Path | None = None) -> Path:
    return (store_dir or default_store_dir()) / OBS_NAME


def outcomes_path(store_dir: Path | None = None) -> Path:
    return (store_dir or default_store_dir()) / OUT_NAME


def archive_limit_bytes() -> int:
    raw = (os.getenv("V2_SHADOW_ARCHIVE_BYTES") or "").strip()
    if not raw:
        return DEFAULT_ARCHIVE_BYTES
    try:
        return int(raw)
    except ValueError:
        return DEFAULT_ARCHIVE_BYTES


def _is_secret_key(key: Any) -> bool:
    name = str(key).lower()
    return any(part in name for part in _SECRET_SUBSTR)


def redact_secrets(obj: Any) -> Any:
    """Drop secret-shaped keys. Never write tokens/passwords to JSONL."""
    if isinstance(obj, dict):
        return {k: redact_secrets(v) for k, v in obj.items() if not _is_secret_key(k)}
    if isinstance(obj, list):
        return [redact_secrets(item) for item in obj]
    return obj


def maybe_archive_jsonl(path: Path, *, limit_bytes: int | None = None) -> Path | None:
    """
    If the active JSONL exceeds the bound, rename it to a timestamped archive.

    Never deletes. limit_bytes <= 0 disables rotation.
    """
    limit = archive_limit_bytes() if limit_bytes is None else limit_bytes
    if limit <= 0 or not path.exists() or path.stat().st_size < limit:
        return None
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    dest = path.with_name(f"{path.stem}.{stamp}{path.suffix}")
    n = 1
    while dest.exists():
        dest = path.with_name(f"{path.stem}.{stamp}_{n}{path.suffix}")
        n += 1
    path.rename(dest)
    return dest


def _append_jsonl(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    maybe_archive_jsonl(path)
    line = json.dumps(redact_secrets(payload), separators=(",", ":"), ensure_ascii=True)
    with path.open("a", encoding="utf-8") as fh:
        fh.write(line + "\n")


def append_observation(decision: V2ShadowDecision, store_dir: Path | None = None) -> Path:
    path = observations_path(store_dir)
    _append_jsonl(path, decision.to_dict())
    return path


def append_outcome(outcome: ShadowOutcome, store_dir: Path | None = None) -> Path:
    path = outcomes_path(store_dir)
    _append_jsonl(path, outcome.to_dict())
    return path
