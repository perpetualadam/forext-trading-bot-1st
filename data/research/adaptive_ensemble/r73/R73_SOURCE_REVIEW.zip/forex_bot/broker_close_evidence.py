"""Fail-closed live close confirmation.

An in-process reservation stops a second close while the first outcome is
unresolved. It is not restart-durable and it is not broker-enforced idempotency.
A helper return, a timeout, and a flat broker book are not filled-unit proof.
"""

from __future__ import annotations

import asyncio
import logging
import threading
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from typing import Any

logger = logging.getLogger(__name__)

CLOSE_NOT_REQUESTED = "CLOSE_NOT_REQUESTED"
CLOSE_PREPARED = "CLOSE_PREPARED"
CLOSE_SUBMITTING = "CLOSE_SUBMITTING"
CLOSE_SUBMITTED = "CLOSE_SUBMITTED"
CLOSE_RESPONSE_RECEIVED = "CLOSE_RESPONSE_RECEIVED"
CLOSE_CONFIRMATION_PENDING = "CLOSE_CONFIRMATION_PENDING"
CLOSE_PARTIALLY_CONFIRMED = "CLOSE_PARTIALLY_CONFIRMED"
CLOSE_FULLY_CONFIRMED = "CLOSE_FULLY_CONFIRMED"
CLOSE_REJECTED_CONFIRMED = "CLOSE_REJECTED_CONFIRMED"
CLOSE_OUTCOME_AMBIGUOUS = "CLOSE_OUTCOME_AMBIGUOUS"
CLOSE_RECONCILIATION_REQUIRED = "CLOSE_RECONCILIATION_REQUIRED"

_BLOCKING = frozenset(
    {
        CLOSE_PREPARED,
        CLOSE_SUBMITTING,
        CLOSE_SUBMITTED,
        CLOSE_RESPONSE_RECEIVED,
        CLOSE_CONFIRMATION_PENDING,
        CLOSE_PARTIALLY_CONFIRMED,
        CLOSE_OUTCOME_AMBIGUOUS,
        CLOSE_RECONCILIATION_REQUIRED,
        CLOSE_FULLY_CONFIRMED,
    }
)

_lock = threading.Lock()
_operations: dict[str, "CloseOperation"] = {}
_recovered: dict[str, "CloseOperation"] = {}
_flat_notes: dict[str, str] = {}


class CloseReadError(RuntimeError):
    def __init__(self, reason: str) -> None:
        self.reason = reason
        super().__init__(reason)


@dataclass
class CloseOperation:
    operation_id: str
    account_scope: str
    instrument: str
    direction: str
    trade_ids: tuple[str, ...]
    local_position_identity: str
    original_units: Decimal | None
    requested_units: Decimal | None
    confirmed_units: Decimal | None
    remaining_units: Decimal | None
    broker_request_identity: str
    transaction_ids: tuple[str, ...]
    submission_state: str
    confirmation_state: str
    error_classification: str
    attempt_count: int
    created_at: str
    updated_at: str
    evidence_source: str
    reason: str = ""
    submission_count: int = 0
    realized_pnl: Decimal | None = None
    transaction_body_retrieved: bool = False

    @property
    def blocks_resubmission(self) -> bool:
        return self.confirmation_state in _BLOCKING


def reset_close_evidence_state() -> None:
    with _lock:
        _operations.clear()
        _recovered.clear()
        _flat_notes.clear()


def close_operation_for(symbol: str) -> CloseOperation | None:
    from forex_bot.symbols import normalize_oanda_symbol

    key = normalize_oanda_symbol(symbol)
    with _lock:
        return _operations.get(key) or _recovered.get(key)


def broker_flat_note(symbol: str) -> str:
    from forex_bot.symbols import normalize_oanda_symbol

    with _lock:
        return _flat_notes.get(normalize_oanda_symbol(symbol), "")


def live_local_delete_permitted(symbol: str) -> bool:
    op = close_operation_for(symbol)
    if op is None or op.confirmation_state != CLOSE_FULLY_CONFIRMED:
        return False
    if op.requested_units is None or op.confirmed_units is None or op.remaining_units is None:
        return False
    return op.confirmed_units == op.requested_units and op.remaining_units == Decimal("0")


def note_unattributed_broker_flat(symbol: str) -> None:
    """Record a flat book without confirming a bot close or erasing an operation."""
    from forex_bot.symbols import normalize_oanda_symbol

    key = normalize_oanda_symbol(symbol)
    with _lock:
        _flat_notes[key] = "broker_flat_not_close_confirmation"


def declare_process_restart() -> None:
    """Keep unresolved operations as in-memory blockers. This does not touch disk."""
    with _lock:
        for key, op in list(_operations.items()):
            if op.confirmation_state in _BLOCKING and op.confirmation_state != CLOSE_FULLY_CONFIRMED:
                op.confirmation_state = CLOSE_RECONCILIATION_REQUIRED
                op.error_classification = "restart_unresolved"
                op.updated_at = _now()
                _recovered[key] = op
            elif op.confirmation_state == CLOSE_FULLY_CONFIRMED:
                _recovered[key] = op
        _operations.clear()


def clear_confirmed_operation(symbol: str) -> None:
    from forex_bot.symbols import normalize_oanda_symbol

    key = normalize_oanda_symbol(symbol)
    with _lock:
        op = _operations.get(key)
        if op is not None and op.confirmation_state == CLOSE_FULLY_CONFIRMED:
            _operations.pop(key, None)
        recovered = _recovered.get(key)
        if recovered is not None and recovered.confirmation_state == CLOSE_FULLY_CONFIRMED:
            _recovered.pop(key, None)


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _decimal(raw: Any, *, label: str) -> Decimal:
    if raw is None:
        raise CloseReadError(f"missing_{label}")
    text = str(raw).replace(",", "").strip()
    if text == "":
        raise CloseReadError(f"missing_{label}")
    try:
        value = Decimal(text)
    except InvalidOperation as exc:
        raise CloseReadError(f"malformed_{label}") from exc
    if not value.is_finite():
        raise CloseReadError(f"nonfinite_{label}")
    return value


def _identity(symbol: str, trade_ids: tuple[str, ...], direction: str, units: Decimal) -> str:
    return f"{symbol}|{','.join(trade_ids)}|{direction}|{units}"


def _blank(
    *,
    instrument: str = "",
    state: str = CLOSE_NOT_REQUESTED,
    reason: str = "",
) -> CloseOperation:
    stamp = _now()
    return CloseOperation(
        operation_id="",
        account_scope="missing",
        instrument=instrument,
        direction="",
        trade_ids=(),
        local_position_identity="",
        original_units=None,
        requested_units=None,
        confirmed_units=None,
        remaining_units=None,
        broker_request_identity="",
        transaction_ids=(),
        submission_state="NOT_SENT",
        confirmation_state=state,
        error_classification=reason,
        attempt_count=0,
        created_at=stamp,
        updated_at=stamp,
        evidence_source="none",
        reason=reason,
    )


def _position_still(op: CloseOperation) -> bool:
    from forex_bot.broker_exit import local_broker_trade_ids
    from forex_bot.positions import positions
    from forex_bot.symbols import normalize_oanda_symbol

    row = positions.get(op.instrument)
    if row is None:
        return False
    if normalize_oanda_symbol(getattr(row, "symbol", "") or "") != op.instrument:
        return False
    if (getattr(row, "direction", "") or "").upper() != op.direction:
        return False
    return tuple(local_broker_trade_ids(row)) == op.trade_ids


def _reserve(pos: Any, trade_ids: tuple[str, ...], units: Decimal, reason: str) -> CloseOperation:
    from forex_bot.symbols import normalize_oanda_symbol

    symbol = normalize_oanda_symbol(getattr(pos, "symbol", "") or "")
    direction = (getattr(pos, "direction", "") or "").upper()
    with _lock:
        recovered = _recovered.get(symbol)
        if recovered is not None and recovered.blocks_resubmission:
            return recovered
        current = _operations.get(symbol)
        if current is not None and current.blocks_resubmission:
            return current
        stamp = _now()
        op = CloseOperation(
            operation_id=uuid.uuid4().hex,
            account_scope="scoped",
            instrument=symbol,
            direction=direction,
            trade_ids=trade_ids,
            local_position_identity=_identity(symbol, trade_ids, direction, units),
            original_units=units,
            requested_units=units,
            confirmed_units=None,
            remaining_units=None,
            broker_request_identity="",
            transaction_ids=(),
            submission_state="NOT_SENT",
            confirmation_state=CLOSE_PREPARED,
            error_classification="",
            attempt_count=0,
            created_at=stamp,
            updated_at=stamp,
            evidence_source="position_close",
            reason=reason,
        )
        _operations[symbol] = op
        return op


def _mark(op: CloseOperation, *, state: str, error: str = "", submission: str | None = None) -> None:
    op.confirmation_state = state
    op.updated_at = _now()
    if error:
        op.error_classification = error
    if submission is not None:
        op.submission_state = submission


def _release_unsent(op: CloseOperation) -> None:
    with _lock:
        current = _operations.get(op.instrument)
        if current is op and op.submission_count == 0 and op.confirmation_state == CLOSE_PREPARED:
            _operations.pop(op.instrument, None)


def _begin_submit(op: CloseOperation) -> bool:
    with _lock:
        current = _operations.get(op.instrument)
        if current is not op or op.confirmation_state != CLOSE_PREPARED:
            return False
        if not _position_still(op):
            _mark(op, state=CLOSE_RECONCILIATION_REQUIRED, error="identity_changed", submission="NOT_SENT")
            return False
        op.attempt_count += 1
        op.submission_count += 1
        _mark(op, state=CLOSE_SUBMITTING, submission="SENDING")
        return True


def _fill_sections(body: dict[str, Any]) -> list[dict[str, Any]]:
    found: list[dict[str, Any]] = []
    for key in ("longOrderFillTransaction", "shortOrderFillTransaction", "orderFillTransaction"):
        value = body.get(key)
        if isinstance(value, dict) and value:
            found.append(value)
    return found


def _reject_section(body: dict[str, Any]) -> dict[str, Any] | None:
    for key in (
        "longOrderCancelTransaction",
        "shortOrderCancelTransaction",
        "orderCancelTransaction",
        "longOrderRejectTransaction",
        "shortOrderRejectTransaction",
        "orderRejectTransaction",
    ):
        value = body.get(key)
        if isinstance(value, dict) and value:
            return value
    return None


def interpret_close_response(
    body: Any,
    *,
    instrument: str,
    trade_id: str,
    direction: str,
    requested_units: Decimal,
) -> dict[str, Any]:
    """Classify a PositionClose body. Does not confirm units until a transaction is retrieved."""
    if not isinstance(body, dict):
        raise CloseReadError("malformed_response")
    fills = _fill_sections(body)
    if len(fills) > 1:
        raise CloseReadError("duplicate_fill_transaction")
    reject = _reject_section(body)
    if not fills and reject is not None:
        return {
            "state": CLOSE_REJECTED_CONFIRMED,
            "confirmed_units": Decimal("0"),
            "remaining_units": requested_units,
            "transaction_ids": (str(reject.get("id") or ""),),
            "error": "broker_reject_or_cancel",
            "needs_transaction": False,
        }
    if not fills:
        raise CloseReadError("missing_fill_transaction")
    fill = fills[0]
    tx_id = str(fill.get("id") or "").strip()
    if not tx_id:
        raise CloseReadError("missing_transaction_id")
    fill_instrument = str(fill.get("instrument") or "").upper().replace("-", "_")
    if fill_instrument and fill_instrument != instrument:
        raise CloseReadError("instrument_mismatch")
    return {
        "state": CLOSE_RESPONSE_RECEIVED,
        "confirmed_units": None,
        "remaining_units": None,
        "transaction_ids": (tx_id,),
        "error": "",
        "needs_transaction": True,
        "direction": direction,
        "trade_id": trade_id,
    }


def apply_transaction_body(
    tx: Any,
    *,
    instrument: str,
    trade_id: str,
    direction: str,
    requested_units: Decimal,
    transaction_id: str,
    account_id: str,
) -> dict[str, Any]:
    """Confirm closed units from a retrieved transaction body."""
    if not isinstance(tx, dict):
        raise CloseReadError("malformed_transaction")
    if str(tx.get("type") or "").upper() != "ORDER_FILL":
        raise CloseReadError("unexpected_transaction_type")
    if str(tx.get("id") or "").strip() != transaction_id:
        raise CloseReadError("transaction_id_mismatch")
    got_account = str(tx.get("accountID") or "").strip()
    if not account_id or not got_account or got_account != account_id:
        raise CloseReadError("account_mismatch")
    got_instrument = str(tx.get("instrument") or "").upper().replace("-", "_")
    if got_instrument != instrument:
        raise CloseReadError("instrument_mismatch")
    side_units = _decimal(tx.get("units"), label="units")
    if direction == "BUY" and side_units >= 0:
        raise CloseReadError("direction_mismatch")
    if direction == "SELL" and side_units <= 0:
        raise CloseReadError("direction_mismatch")
    closed_rows = tx.get("tradesClosed")
    if not isinstance(closed_rows, list):
        raise CloseReadError("missing_closed_trade_details")
    seen: set[str] = set()
    matched = Decimal("0")
    other = Decimal("0")
    for row in closed_rows:
        if not isinstance(row, dict):
            raise CloseReadError("malformed_transaction")
        row_trade = str(row.get("tradeID") or "").strip()
        if not row_trade or row_trade in seen:
            raise CloseReadError("duplicate_transaction_id")
        seen.add(row_trade)
        units = abs(_decimal(row.get("units"), label="units"))
        if row_trade == trade_id:
            matched += units
        else:
            other += units
    if matched == 0 and trade_id not in seen:
        raise CloseReadError("trade_id_mismatch")
    if matched == 0:
        return {
            "state": CLOSE_RECONCILIATION_REQUIRED,
            "confirmed_units": Decimal("0"),
            "remaining_units": requested_units,
            "error": "zero_confirmed_units",
            "account_scope": "matched",
        }
    if other > 0 or matched > requested_units:
        return {
            "state": CLOSE_RECONCILIATION_REQUIRED,
            "confirmed_units": matched,
            "remaining_units": None,
            "error": "unit_mismatch",
            "account_scope": "matched",
        }
    if matched < requested_units:
        return {
            "state": CLOSE_PARTIALLY_CONFIRMED,
            "confirmed_units": matched,
            "remaining_units": requested_units - matched,
            "error": "partial_fill",
            "account_scope": "matched",
        }
    return {
        "state": CLOSE_FULLY_CONFIRMED,
        "confirmed_units": matched,
        "remaining_units": Decimal("0"),
        "error": "",
        "account_scope": "matched",
    }


def _fetch_transaction(transaction_id: str) -> dict[str, Any]:
    from forex_bot.config import Config
    from forex_bot.oanda_client import get_api

    api = get_api()
    account = (Config.OANDA_ACCOUNT_ID or "").strip()
    if api is None:
        raise CloseReadError("missing_client")
    if not account:
        raise CloseReadError("missing_account")
    try:
        import oandapyV20.endpoints.transactions as tx_ep

        from forex_bot.oanda_client import _oanda_request
    except ModuleNotFoundError as exc:
        raise CloseReadError("reader_unavailable") from exc
    request = tx_ep.TransactionDetails(accountID=account, transactionID=transaction_id)
    try:
        body = _oanda_request(api, request, context="close transaction details")
    except TimeoutError as exc:
        raise CloseReadError("timeout") from exc
    except CloseReadError:
        raise
    except Exception as exc:
        raise CloseReadError("request_exception") from exc
    if not isinstance(body, dict):
        raise CloseReadError("malformed_transaction")
    tx = body.get("transaction")
    if not isinstance(tx, dict):
        raise CloseReadError("missing_transaction_body")
    return tx


def _apply_verified(op: CloseOperation, result: dict[str, Any]) -> None:
    op.confirmation_state = str(result["state"])
    op.confirmed_units = result.get("confirmed_units")
    op.remaining_units = result.get("remaining_units")
    op.error_classification = str(result.get("error") or "")
    if result.get("account_scope"):
        op.account_scope = str(result["account_scope"])
    op.transaction_body_retrieved = op.confirmation_state in {
        CLOSE_FULLY_CONFIRMED,
        CLOSE_PARTIALLY_CONFIRMED,
        CLOSE_RECONCILIATION_REQUIRED,
    }
    op.evidence_source = "transaction_details"
    op.updated_at = _now()


async def run_guarded_live_close(pos: Any, *, reason: str) -> CloseOperation:
    """Reserve, submit through the existing position-close helper, then verify units."""
    from forex_bot.broker_exit import local_broker_trade_ids
    from forex_bot.positions import position_management_permitted
    from forex_bot.symbols import normalize_oanda_symbol

    symbol = normalize_oanda_symbol(getattr(pos, "symbol", "") or "")
    if not position_management_permitted(pos):
        return _blank(instrument=symbol, reason="management_not_permitted")
    if (getattr(pos, "execution_kind", "") or "").strip().lower() != "live":
        return _blank(instrument=symbol, reason="not_live_close")
    trade_ids = tuple(local_broker_trade_ids(pos))
    if len(trade_ids) != 1:
        error = "missing_trade_id" if not trade_ids else "multiple_trade_ids"
        op = _reserve_blocked(pos, trade_ids, error)
        return op
    try:
        units = _decimal(getattr(pos, "units", None), label="units")
    except CloseReadError as exc:
        return _reserve_blocked(pos, trade_ids, exc.reason)
    if units != units.to_integral_value():
        return _reserve_blocked(pos, trade_ids, "fractional_units")
    op = _reserve(pos, trade_ids, units, reason)
    if op.confirmation_state != CLOSE_PREPARED:
        return op
    try:
        from forex_bot.oanda_exec import assert_broker_order_allowed

        assert_broker_order_allowed(execution_kind="live", action="close")
    except Exception:
        _release_unsent(op)
        return _blank(instrument=symbol, reason="broker_orders_disabled")
    if not _begin_submit(op):
        return close_operation_for(symbol) or op
    try:
        from forex_bot.oanda_exec import _submit_position_close_body

        body = await asyncio.to_thread(
            _submit_position_close_body, symbol, float(units), op.direction
        )
    except TimeoutError:
        _mark(op, state=CLOSE_OUTCOME_AMBIGUOUS, error="timeout", submission="SENT")
        return op
    except Exception:
        _mark(op, state=CLOSE_OUTCOME_AMBIGUOUS, error="request_exception", submission="SENT")
        return op
    _mark(op, state=CLOSE_RESPONSE_RECEIVED, submission="SENT")
    try:
        parsed = interpret_close_response(
            body,
            instrument=symbol,
            trade_id=trade_ids[0],
            direction=op.direction,
            requested_units=units,
        )
    except CloseReadError as exc:
        state = CLOSE_RECONCILIATION_REQUIRED if exc.reason.endswith("mismatch") or exc.reason.startswith("duplicate") else CLOSE_OUTCOME_AMBIGUOUS
        _mark(op, state=state, error=exc.reason, submission="SENT")
        return op
    op.transaction_ids = tuple(item for item in parsed["transaction_ids"] if item)
    if parsed["state"] == CLOSE_REJECTED_CONFIRMED:
        op.confirmed_units = Decimal("0")
        op.remaining_units = units
        _mark(op, state=CLOSE_REJECTED_CONFIRMED, error="broker_reject_or_cancel", submission="SENT")
        with _lock:
            if _operations.get(symbol) is op:
                _operations.pop(symbol, None)
        return op
    if not _position_still(op):
        _mark(op, state=CLOSE_RECONCILIATION_REQUIRED, error="identity_changed", submission="SENT")
        return op
    tx_id = op.transaction_ids[0] if op.transaction_ids else ""
    if not tx_id:
        _mark(op, state=CLOSE_OUTCOME_AMBIGUOUS, error="missing_transaction_id", submission="SENT")
        return op
    try:
        from forex_bot.config import Config

        tx = _fetch_transaction(tx_id)
        if not _position_still(op):
            _mark(op, state=CLOSE_RECONCILIATION_REQUIRED, error="identity_changed", submission="SENT")
            return op
        verified = apply_transaction_body(
            tx,
            instrument=symbol,
            trade_id=trade_ids[0],
            direction=op.direction,
            requested_units=units,
            transaction_id=tx_id,
            account_id=(Config.OANDA_ACCOUNT_ID or "").strip(),
        )
    except CloseReadError as exc:
        pending = exc.reason in {"timeout", "request_exception", "missing_client", "missing_transaction_body", "reader_unavailable"}
        _mark(
            op,
            state=CLOSE_CONFIRMATION_PENDING if pending else CLOSE_RECONCILIATION_REQUIRED,
            error=exc.reason,
            submission="SENT",
        )
        op.evidence_source = "transaction_details"
        return op
    _apply_verified(op, verified)
    logger.info(
        "[CLOSE EVIDENCE] instrument=%s state=%s confirmed=%s remaining=%s reason=%s",
        op.instrument,
        op.confirmation_state,
        op.confirmed_units,
        op.remaining_units,
        op.error_classification,
    )
    return op


def _reserve_blocked(pos: Any, trade_ids: tuple[str, ...], error: str) -> CloseOperation:
    from forex_bot.symbols import normalize_oanda_symbol

    symbol = normalize_oanda_symbol(getattr(pos, "symbol", "") or "")
    with _lock:
        current = _operations.get(symbol) or _recovered.get(symbol)
        if current is not None and current.blocks_resubmission:
            return current
        stamp = _now()
        op = CloseOperation(
            operation_id=uuid.uuid4().hex,
            account_scope="scoped",
            instrument=symbol,
            direction=(getattr(pos, "direction", "") or "").upper(),
            trade_ids=trade_ids,
            local_position_identity=symbol,
            original_units=None,
            requested_units=None,
            confirmed_units=None,
            remaining_units=None,
            broker_request_identity="",
            transaction_ids=(),
            submission_state="NOT_SENT",
            confirmation_state=CLOSE_RECONCILIATION_REQUIRED,
            error_classification=error,
            attempt_count=0,
            created_at=stamp,
            updated_at=stamp,
            evidence_source="none",
            reason=error,
        )
        _operations[symbol] = op
        return op
