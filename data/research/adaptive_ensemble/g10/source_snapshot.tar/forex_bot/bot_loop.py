"""Evaluation loop, evolution, and daily reporting."""

from __future__ import annotations

import asyncio
import logging
import math
import os
import time
from datetime import datetime, timezone

from forex_bot.ai_ensemble import ai
from forex_bot.alerts import alert
from forex_bot.analytics import analytics
from forex_bot.config import Config
from forex_bot.execution import (
    close_fill_path,
    effective_paper_trading,
    is_broker_backed,
    is_paper_like_kind,
    open_fill_path,
    pre_trade_entry_blocked_reason,
)
from forex_bot.indicators import compute_indicators
from forex_bot.live_manage import ManageQuote
from forex_bot.nn_pred import compute_nn_pred
import forex_bot.oanda_exec as oanda_exec
from forex_bot.oanda_client import (
    fetch_account_summary,
    fetch_ohlcv,
    fetch_pricing_snapshot,
    last_account_summary,
)
from forex_bot.execution_metrics import record_fill_failure, record_fill_quality
from forex_bot.orders import (
    OrderStatus,
    finalize_order_fill,
    generate_client_order_id,
    mark_order_failed_or_cancelled,
    try_begin_order_submission,
)
from forex_bot.portfolio_exposure import (
    approx_gross_usd_notional_for,
    configured_max_gross_usd,
    format_notional_cap_report,
    format_notional_cap_skip_alert,
    format_usd_direction_skip,
    notional_cap_decision,
    notional_pct_of_nav,
    portfolio_gross_notional_pct_of_nav,
    same_usd_direction_open_positions,
    usd_direction,
    usd_direction_guard_decision,
)
from forex_bot.portfolio import PortfolioEngine
from forex_bot.positions import Position, close_position, get_position, open_position, positions as position_map
from forex_bot.profit_protection import (
    ProtectionDecision,
    apply_profit_protection,
    mark_protection_close_attempt,
    original_tp_distance_pips,
    pip_size as _pip_size,
    protection_close_allowed,
    raise_mfe_from_post_entry_ohlcv,
    seed_position_mfe,
    unrealized_profit_pips,
)
from forex_bot.rl_agent import RLAgent
from forex_bot.session_rules import (
    flatten_for_weekend,
    in_active_session,
    is_live_trading,
    live_window_log_enabled,
    log_live_windows,
    pre_close_adjustment,
    symbol_live_window_status,
    volatility_ok,
)
from forex_bot.operational_events import record_operational_transition_if_changed
from forex_bot.state import (
    current_equity,
    last_report_ts,
    pricing_snapshot,
    record_mid,
    set_last_report_ts,
    set_pricing_snapshot,
    state as state_dict,
)
from forex_bot.decision_skip_log import (
    CANDLE_ACQUISITION_FAILED,
    CANDLE_INTERNAL_ERROR,
    CANDLE_PARSING_FAILED,
    CYCLE_INTEGRITY_FAILED,
    DECISION_CANDLES_EMPTY,
    DECISION_CANDLES_FETCH_FAILED,
    DECISION_CANDLES_MISSING,
    DECISION_CANDLES_UNVERIFIED,
    ENTRY_SKIPPED_NO_VALID_CANDLES,
    INSTRUMENT_CYCLE_FAILED,
    LIVE_ORDER_AUTH_BLOCKED,
    MANAGEMENT_CONTINUED_WITHOUT_CANDLES,
    MANAGEMENT_QUOTE_STALE,
    MANAGEMENT_QUOTE_UNAVAILABLE,
    MANAGEMENT_UNAVAILABLE,
    MARKET_SESSION_CLOSED,
    NO_OHLCV,
    NO_STRATEGY_SELECTED,
    POSITION_ALREADY_OPEN,
    PROTECTIVE_CLOSE_FAILED,
    PROTECTIVE_CLOSE_UNCONFIRMED,
    QUANT_AI_REJECTED,
    RECONCILE_OR_PRETRADE_BLOCKED,
    RL_DIRECTION_MISMATCH,
    RL_SKIP,
    RL_STATE_UNAVAILABLE,
    SIZING_BELOW_MIN,
    STALE_OR_INVALID_DATA,
    STRATEGY_INACTIVE,
    STRATEGY_NOT_AUTHORISED,
    VOLATILITY_UNSAFE,
    WEEKEND_FLATTEN,
    log_decision_skip,
    log_strategy_pre_sizing_skip,
)
from forex_bot.strategy_meta import select_strategy, seq_model, strategies
from forex_bot.entry_geometry import (
    fetch_entry_pricing,
    format_entry_fill_geometry_line,
    format_entry_geometry_line,
    format_entry_geometry_skip,
    live_broker_geometry_required,
    resolve_live_entry_geometry,
)
from forex_bot.trading import (
    apply_execution_costs,
    apply_latency,
    apply_market_impact,
    calculate_pnl,
    cap_position_units,
    configured_max_portfolio_risk_pct,
    execute_trade,
    portfolio_risk_amount,
    portfolio_risk_cap_exceeded,
    position_sizing,
    sl_tp_distance_for_entry,
    stop_risk_account_ccy,
    strategy_execution_style,
)

logger = logging.getLogger(__name__)

rl_agent = RLAgent()


def _safe_audit(**fields: object) -> None:
    """Merge into the current evaluation session, or append a standalone record."""
    try:
        from forex_bot.decision_repair.audit import current_audit
        from forex_bot.live_safety import live_order_auth_state

        cur = current_audit()
        payload = {k: v for k, v in fields.items() if v is not None}
        if "live_order_auth_state" not in payload:
            payload["live_order_auth_state"] = live_order_auth_state()
        if cur is not None:
            cur.update(**payload)
            return
        from forex_bot.decision_repair.flags import audit_enabled
        from forex_bot.decision_repair.audit import append_record_safe, empty_record

        if not audit_enabled():
            return
        rec = empty_record(symbol=str(fields.get("symbol") or ""))
        rec.update(payload)
        append_record_safe(rec)
    except Exception:
        logger.exception("decision audit append failed (ignored)")


def _audit_reject(reason: str, *, stage: str) -> None:
    try:
        from forex_bot.decision_repair.audit import reject_current

        reject_current(reason, stage=stage)
    except Exception:
        logger.exception("decision audit reject stamp failed (ignored)")


def _audit_close(*, outcome: str, trigger: str, evidence: str = "NOT_EVALUATED") -> None:
    """Never blocks a protective close."""
    try:
        from forex_bot.decision_repair.audit import current_audit

        cur = current_audit()
        if cur is None:
            return
        cur.note_close(outcome=outcome, trigger=trigger, evidence=evidence)
    except Exception:
        logger.exception("decision audit close stamp failed (ignored; close not blocked)")


def _permit_new_exposure_or_block() -> bool:
    """Fail closed for new exposure when the audit flag is on and the write fails."""
    try:
        from forex_bot.decision_repair.audit import current_audit

        cur = current_audit()
        if cur is None:
            return True
        return bool(cur.permit_new_exposure())
    except Exception:
        logger.exception("decision audit new-exposure persist failed (blocked)")
        return False
portfolio = PortfolioEngine()

_last_performance_log_ts: float = 0.0


def _performance_log_enabled() -> bool:
    return (os.getenv("PERFORMANCE_LOG") or "1").strip().lower() not in ("0", "false", "no", "off")


def _performance_log_interval_sec() -> float:
    try:
        return max(0.0, float((os.getenv("PERFORMANCE_LOG_INTERVAL_SEC") or "0").strip() or "0"))
    except ValueError:
        return 0.0


def _maybe_log_performance_metrics() -> None:
    """One identifiable [PERFORMANCE] line per bot cycle, or throttled by PERFORMANCE_LOG_INTERVAL_SEC."""
    global _last_performance_log_ts
    if not _performance_log_enabled():
        return
    now = time.time()
    interval = _performance_log_interval_sec()
    if interval > 0 and (now - _last_performance_log_ts) < interval:
        return
    _last_performance_log_ts = now
    import forex_bot.positions as posmod

    eq = current_equity()
    pf = analytics.profit_factor()
    if pf is None:
        pf_s = "n/a"
    elif pf == float("inf"):
        pf_s = "inf"
    else:
        pf_s = f"{float(pf):.4f}"
    logger.info(
        "[PERFORMANCE] equity=%.2f sharpe=%.4f win_rate_pct=%.2f winrate=%.4f drawdown=%.2f "
        "closed_trades=%s profit_factor=%s open_positions=%s open_symbols=%s",
        eq,
        analytics.sharpe(),
        analytics.win_rate_pct(),
        analytics.winrate(),
        analytics.drawdown(),
        len(analytics.trades),
        pf_s,
        len(posmod.positions),
        sorted(posmod.positions.keys()),
    )


def _env_int(name: str, default: int) -> int:
    v = (os.getenv(name) or "").strip()
    return int(v) if v else default


def _min_position_hold_sec() -> float:
    """Seconds to hold before SL/TP exits apply; 0 = disabled (immediate exit on touch)."""
    try:
        return max(0.0, float((os.getenv("MIN_POSITION_HOLD_SEC") or "0").strip() or "0"))
    except ValueError:
        return 0.0


def _position_log_enabled() -> bool:
    return (os.getenv("POSITION_LOG") or "1").strip().lower() not in ("0", "false", "no", "off")


def _log_open_position_line(symbol: str, pos: Position, price: float) -> None:
    """Lightweight snapshot: no extra API/DB; uses current bar mid from evaluate()."""
    mtm = calculate_pnl(pos, price)
    if mtm > 1e-12:
        side = "winning"
    elif mtm < -1e-12:
        side = "losing"
    else:
        side = "flat"
    age_sec = time.time() - float(pos.open_time)
    pip = _pip_size(symbol)
    if pos.direction == "BUY":
        d_sl = float(price) - float(pos.stop_loss)
        d_tp = float(pos.take_profit) - float(price)
    else:
        d_sl = float(pos.stop_loss) - float(price)
        d_tp = float(price) - float(pos.take_profit)
    p_sl = d_sl / pip if pip else 0.0
    p_tp = d_tp / pip if pip else 0.0
    mh = _min_position_hold_sec()
    if mh > 0:
        hold_part = f"min_hold_remain_sec={max(0.0, mh - age_sec):.0f}"
    else:
        hold_part = "min_hold_remain_sec=n/a"
    logger.info(
        "[POSITION] %s dir=%s age_sec=%.0f mtm_pnl=%.5f side=%s mid=%.5f entry=%.5f "
        "dist_to_sl_price=%.5f dist_to_tp_price=%.5f dist_to_sl_pips=%.1f dist_to_tp_pips=%.1f %s",
        symbol,
        pos.direction,
        age_sec,
        mtm,
        side,
        price,
        pos.entry_price,
        d_sl,
        d_tp,
        p_sl,
        p_tp,
        hold_part,
    )


def _refresh_pricing_snapshot() -> None:
    """One batched PricingInfo GET per bot cycle. Never writes."""
    try:
        snap = fetch_pricing_snapshot(Config.SYMBOLS)
    except Exception:
        logger.exception("pricing snapshot failed")
        snap = {}
    set_pricing_snapshot(snap)


def _m5_bar_time(raw) -> str:
    try:
        return str(raw["time"].iloc[-1])
    except Exception:
        return ""


def _tp_progress(pos: Position) -> float | None:
    dist = original_tp_distance_pips(pos)
    mfe = float(getattr(pos, "max_profit_pips", 0.0) or 0.0)
    if dist is None or dist <= 0:
        return None
    return mfe / dist


def _df_last(df, column: str) -> float | None:
    if column not in df.columns:
        return None
    raw = df[column].iloc[-1]
    try:
        val = float(raw)
    except (TypeError, ValueError):
        return None
    if val != val:
        return None
    return val


def _persist_v2_shadow_market_m5(symbol: str, raw) -> None:
    """Research-only. Uses already-fetched M5. Return discarded. Never authorizes."""
    from forex_bot.v2_shadow.market import maybe_record_completed_m5

    maybe_record_completed_m5(symbol, raw)


def _observe_v2_shadow_candidate(
    *,
    symbol: str,
    strategy_name: str,
    direction: str,
    price: float,
    df,
    atr_v: float,
    ma_fast: float,
    ma_slow: float,
    ret_1: float,
    rl_action: str,
    rl_state: str,
) -> None:
    """Shadow-only. Return is discarded. Must never change production direction."""
    from forex_bot.v2_shadow import maybe_observe_candidate

    quote = pricing_snapshot().get(symbol)
    bid = getattr(quote, "bid", None) if quote is not None else None
    ask = getattr(quote, "ask", None) if quote is not None else None
    if bid is None and quote is not None:
        bid = getattr(quote, "closeout_bid", None)
    if ask is None and quote is not None:
        ask = getattr(quote, "closeout_ask", None)
    now_utc = datetime.now(timezone.utc)
    rets: dict[str, float | None] = {}
    for label, steps in (("ret_5", 1), ("ret_15", 3), ("ret_30", 6)):
        if len(df) > steps:
            c0 = float(df["close"].iloc[-1])
            c1 = float(df["close"].iloc[-1 - steps])
            rets[label] = ((c0 - c1) / c1) if c1 else None
        else:
            rets[label] = None
    n_broker = sum(1 for p in position_map.values() if is_broker_backed(p))
    usd_dir = usd_direction(symbol, direction)
    usd_count = len(same_usd_direction_open_positions(usd_dir)) if usd_dir else None
    acct = last_account_summary() or {}
    exposure = acct.get("positionValue")
    if exposure is None:
        exposure = acct.get("NAV")
    maybe_observe_candidate(
        symbol=symbol,
        strategy_label=strategy_name,
        production_side=direction,
        mid=price,
        bid=float(bid) if bid is not None else None,
        ask=float(ask) if ask is not None else None,
        pip_size=_pip_size(symbol),
        atr=None if atr_v != atr_v else atr_v,
        sma_fast=None if ma_fast != ma_fast else ma_fast,
        sma_slow=None if ma_slow != ma_slow else ma_slow,
        rsi=_df_last(df, "rsi"),
        macd=_df_last(df, "macd"),
        boll_up=_df_last(df, "boll_up"),
        boll_down=_df_last(df, "boll_down"),
        ret_1=None if ret_1 != ret_1 else ret_1,
        ret_5=rets["ret_5"],
        ret_15=rets["ret_15"],
        ret_30=rets["ret_30"],
        hour_utc=now_utc.hour,
        day_of_week=now_utc.weekday(),
        usd_direction=usd_dir,
        broker_backed_position_count=n_broker,
        gross_portfolio_exposure=float(exposure) if exposure is not None else None,
        same_usd_direction_count=usd_count,
        rl_action=rl_action,
        rl_state=rl_state,
        rl_q_values=dict(rl_agent.q.get(rl_state) or {}),
        rl_epsilon=float(rl_agent.epsilon),
    )


class CycleIntegrityError(RuntimeError):
    """Shared-state failure. Stop the rest of this symbol cycle."""


def _record_candle_failure(symbol: str, reason: str) -> None:
    """Record a decision-candle failure without logging broker payloads."""
    logger.warning("%s: %s", symbol, reason)
    log_decision_skip(symbol=symbol, reason=reason, stage="data")
    if reason == DECISION_CANDLES_UNVERIFIED:
        log_decision_skip(symbol=symbol, reason=STALE_OR_INVALID_DATA, stage="data")
        return
    if reason != NO_OHLCV:
        log_decision_skip(symbol=symbol, reason=NO_OHLCV, stage="data")


def _skip_new_entry_without_candles(symbol: str, audit_reason: str = NO_OHLCV) -> None:
    log_decision_skip(symbol=symbol, reason=ENTRY_SKIPPED_NO_VALID_CANDLES, stage="data")
    log_decision_skip(symbol=symbol, reason=audit_reason, stage="data")


def _candle_exception_kind(exc: BaseException) -> str:
    """Classify a candle-boundary failure. Integrity errors are not passed here."""
    from forex_bot.market_provenance import ProvenanceRejected

    if isinstance(exc, ProvenanceRejected):
        return CANDLE_INTERNAL_ERROR
    if isinstance(exc, (ValueError, KeyError, TypeError, ArithmeticError)):
        return CANDLE_PARSING_FAILED
    if isinstance(exc, RuntimeError):
        return CANDLE_INTERNAL_ERROR
    return CANDLE_ACQUISITION_FAILED


def _contain_candle_exception(symbol: str, exc: BaseException) -> tuple[None, str]:
    """Candles are unavailable. This does not decide whether a position can be managed."""
    kind = _candle_exception_kind(exc)
    logger.warning("%s: %s (%s)", symbol, kind, type(exc).__name__)
    log_decision_skip(symbol=symbol, reason=kind, stage="data")
    _record_candle_failure(symbol, DECISION_CANDLES_FETCH_FAILED)
    return None, NO_OHLCV


async def _load_decision_candles(symbol: str, count: int):
    """Load the decision frame. Acquisition failure returns None and never fabricates bars.

    The second value is the audit reason that must stay last when no entry is made.
    ``CycleIntegrityError`` is the only acquisition-call failure that stops the cycle.
    """
    try:
        raw = await asyncio.to_thread(fetch_ohlcv, symbol, "M5", count)
    except CycleIntegrityError:
        raise
    except AssertionError:
        raise
    except Exception as exc:  # noqa: BLE001 — candle failures must not skip position management
        return _contain_candle_exception(symbol, exc)
    try:
        if raw is None:
            _record_candle_failure(symbol, DECISION_CANDLES_MISSING)
            return None, NO_OHLCV
        if bool(getattr(raw, "empty", True)):
            _record_candle_failure(symbol, DECISION_CANDLES_EMPTY)
            return None, NO_OHLCV
        if "close" not in raw.columns or bool(raw["close"].isna().iloc[-1]):
            logger.warning("Incomplete OHLCV for %s", symbol)
            _record_candle_failure(symbol, DECISION_CANDLES_UNVERIFIED)
            return None, STALE_OR_INVALID_DATA
    except CycleIntegrityError:
        raise
    except AssertionError:
        raise
    except Exception:  # noqa: BLE001 — a malformed frame is unverified, not a cycle abort
        logger.warning("%s: decision candle frame could not be validated", symbol)
        _record_candle_failure(symbol, DECISION_CANDLES_UNVERIFIED)
        return None, STALE_OR_INVALID_DATA
    return raw, None


def _normalise_instrument(value: object) -> str:
    return str(value or "").replace("/", "_").replace("-", "_").upper()


def _screen_manage_quote(
    symbol: str, quote: ManageQuote | None
) -> tuple[ManageQuote | None, str | None]:
    """Check instrument identity and bid/ask. Freshness stays in resolve_broker_manage_price."""
    if quote is None:
        return None, MANAGEMENT_QUOTE_UNAVAILABLE
    if _normalise_instrument(getattr(quote, "instrument", "")) != _normalise_instrument(symbol):
        return None, MANAGEMENT_QUOTE_UNAVAILABLE
    bid = getattr(quote, "bid", None)
    ask = getattr(quote, "ask", None)
    if bid is not None or ask is not None:
        try:
            bid_f = float(bid) if bid is not None else None
            ask_f = float(ask) if ask is not None else None
        except (TypeError, ValueError):
            return None, MANAGEMENT_QUOTE_UNAVAILABLE
        if (
            bid_f is None
            or ask_f is None
            or not math.isfinite(bid_f)
            or not math.isfinite(ask_f)
            or bid_f <= 0
            or ask_f <= 0
            or bid_f > ask_f
        ):
            return None, MANAGEMENT_QUOTE_UNAVAILABLE
    from forex_bot.live_manage import MANAGE_PRICE_STALE_SEC, quote_age_sec

    age = quote_age_sec(quote)
    if age is not None and age > float(MANAGE_PRICE_STALE_SEC):
        return quote, MANAGEMENT_QUOTE_STALE
    return quote, None


def _position_close_identity(pos: Position) -> tuple[str, float] | None:
    side = str(getattr(pos, "direction", "") or "").upper().strip()
    if side not in ("BUY", "SELL"):
        return None
    try:
        units = float(pos.units)
    except (TypeError, ValueError):
        return None
    if not math.isfinite(units) or units <= 0:
        return None
    return side, units


def _close_exception_reason(exc: BaseException) -> str:
    text = str(exc).lower()
    if isinstance(exc, TimeoutError) or "timed out" in text or "timeout" in text:
        return PROTECTIVE_CLOSE_UNCONFIRMED
    return PROTECTIVE_CLOSE_FAILED


async def _cycle_symbols(symbols) -> None:
    """Run one symbol at a time. An isolated failure does not skip the remaining names."""
    for symbol in symbols:
        try:
            await evaluate(symbol)
        except CycleIntegrityError:
            logger.exception("instrument cycle integrity failure on %s", symbol)
            log_decision_skip(symbol=symbol, reason=CYCLE_INTEGRITY_FAILED, stage="cycle")
            log_decision_skip(
                symbol=symbol,
                reason=INSTRUMENT_CYCLE_FAILED,
                stage="cycle",
                detail="integrity",
            )
            raise
        except Exception:
            logger.exception("instrument_cycle_failed %s", symbol)
            log_decision_skip(symbol=symbol, reason=INSTRUMENT_CYCLE_FAILED, stage="cycle")


async def evaluate(symbol: str) -> None:
    """Evaluate one symbol. Audit session is best-effort except fail-closed new exposure."""
    from forex_bot.decision_repair.audit import EvaluationAudit

    session = EvaluationAudit.start(symbol)
    try:
        await _evaluate_impl(symbol)
    except Exception:
        session.note_error("UNEXPECTED_EVALUATION_ERROR")
        raise
    finally:
        session.finish()


async def _evaluate_impl(symbol: str) -> None:
    """Evaluate: manage open positions (TP/SL) or open new risk-based positions (hybrid + AI + RL)."""
    ohlcv_count = _env_int("HYBRID_OHLCV_COUNT", 200)
    raw, candle_audit = await _load_decision_candles(symbol, ohlcv_count)
    price = None
    if raw is not None:
        try:
            from forex_bot.decision_repair.audit import candle_fingerprint

            last = raw.iloc[-1]
            _safe_audit(
                candle_time=str(last["time"]) if "time" in raw.columns else "NOT_EVALUATED",
                candle_fingerprint=candle_fingerprint(
                    {k: last[k] for k in ("time", "open", "high", "low", "close") if k in raw.columns}
                ),
            )
        except Exception:
            logger.exception("decision audit candle stamp failed (ignored)")
        try:
            _persist_v2_shadow_market_m5(symbol, raw)
        except Exception:
            logger.exception("[V2 SHADOW] market persist failed (ignored)")
        price = float(raw["close"].iloc[-1])
        record_mid(symbol, price)

    try:
        pos = get_position(symbol)
    except CycleIntegrityError:
        raise
    except Exception:
        logger.exception("%s: position state unavailable", symbol)
        log_decision_skip(symbol=symbol, reason=MANAGEMENT_UNAVAILABLE, stage="position")
        log_decision_skip(
            symbol=symbol,
            reason=INSTRUMENT_CYCLE_FAILED,
            stage="position",
            detail="position_state_unavailable",
        )
        return
    if raw is None and pos is not None:
        log_decision_skip(symbol=symbol, reason=MANAGEMENT_CONTINUED_WITHOUT_CANDLES, stage="position")
    if raw is None and pos is None:
        _skip_new_entry_without_candles(symbol, candle_audit or NO_OHLCV)
        return
    weekend_flat = flatten_for_weekend()
    # Session / weekend-flatten gates block *new entries* only — always manage open risk first.
    if pos is None and (not in_active_session(symbol) or weekend_flat):
        if weekend_flat:
            logger.info("%s: skip new open — weekend flatten window (before Friday FX close)", symbol)
            log_decision_skip(symbol=symbol, reason=WEEKEND_FLATTEN, stage="session")
        else:
            alert(f"{symbol}: Market closed, skipping trade")
            log_decision_skip(symbol=symbol, reason=MARKET_SESSION_CLOSED, stage="session")
        return

    if pos:
        log_decision_skip(symbol=symbol, reason=POSITION_ALREADY_OPEN, stage="position")
        from forex_bot.live_manage import (
            PRICE_SOURCE_PAPER_CANDLE,
            broker_sl_tp_hit,
            format_close_decision_line,
            format_manage_price_line,
            resolve_broker_manage_price,
        )

        m5_close = price
        m5_time = _m5_bar_time(raw) if raw is not None else ""
        quote = None
        quote_diag = None
        if is_broker_backed(pos):
            try:
                snap = pricing_snapshot()
            except CycleIntegrityError:
                raise
            except Exception:
                logger.exception("%s: management quote lookup failed", symbol)
                snap = {}
            quote = snap.get(pos.symbol) or snap.get(symbol) if isinstance(snap, dict) else None
            quote, quote_diag = _screen_manage_quote(symbol, quote)
            if quote_diag == MANAGEMENT_QUOTE_STALE:
                log_decision_skip(symbol=symbol, reason=MANAGEMENT_QUOTE_STALE, stage="position")
            elif quote_diag == MANAGEMENT_QUOTE_UNAVAILABLE:
                log_decision_skip(symbol=symbol, reason=MANAGEMENT_QUOTE_UNAVAILABLE, stage="position")
            manage_price, price_source = resolve_broker_manage_price(quote, pos.direction)
        else:
            manage_price = m5_close
            price_source = PRICE_SOURCE_PAPER_CANDLE
            if manage_price is None:
                log_decision_skip(symbol=symbol, reason=MANAGEMENT_QUOTE_UNAVAILABLE, stage="position")

        log_px = manage_price if manage_price is not None else m5_close
        if _position_log_enabled() and log_px is not None:
            _log_open_position_line(symbol, pos, float(log_px))

        current_pips = None
        if manage_price is not None:
            current_pips = unrealized_profit_pips(
                pos.symbol, pos.direction, pos.entry_price, manage_price
            )
            if is_broker_backed(pos):
                seed_position_mfe(
                    pos, manage_price, raw, include_partial_entry_bar=False
                )
                if raw is not None:
                    raise_mfe_from_post_entry_ohlcv(pos, raw)
            else:
                seed_position_mfe(pos, manage_price, raw)
            pp = apply_profit_protection(pos, manage_price, ohlcv=raw)
        else:
            pp = ProtectionDecision(
                enabled=True,
                current_pips=0.0,
                max_profit_pips=float(getattr(pos, "max_profit_pips", 0.0) or 0.0),
                active=bool(getattr(pos, "profit_protection_active", False)),
                exit_threshold_pips=getattr(pos, "profit_protection_exit_pips", None),
                should_close=False,
                just_activated=False,
                just_ratcheted=False,
            )

        if is_broker_backed(pos):
            logger.info(
                format_manage_price_line(
                    symbol=symbol,
                    broker_id=str(getattr(pos, "broker_order_id", "") or ""),
                    side=pos.direction,
                    source=price_source,
                    current_price=manage_price,
                    closeout_bid=getattr(quote, "closeout_bid", None) if quote else None,
                    closeout_ask=getattr(quote, "closeout_ask", None) if quote else None,
                    m5_close=m5_close,
                    m5_time=m5_time,
                    fill=float(pos.entry_price),
                    fill_time=str(pos.open_time),
                    current_pips=current_pips,
                    mfe_pips=float(getattr(pos, "max_profit_pips", 0.0) or 0.0),
                    tp_progress=_tp_progress(pos),
                )
            )

        sl_tp_hit = False
        if is_broker_backed(pos):
            sl_tp_hit = broker_sl_tp_hit(pos)
        elif manage_price is not None:
            if pos.direction == "BUY":
                sl_tp_hit = manage_price <= pos.stop_loss or manage_price >= pos.take_profit
            else:
                sl_tp_hit = manage_price >= pos.stop_loss or manage_price <= pos.take_profit
        protect_hit = bool(pp.should_close)
        if is_broker_backed(pos) and manage_price is None:
            protect_hit = False
        if manage_price is not None:
            price = float(manage_price)
        if protect_hit and not protection_close_allowed(pos):
            logger.warning(
                "%s: profit-protection close deferred — previous close attempt still cooling down",
                symbol,
            )
            protect_hit = False
        close_hit = sl_tp_hit

        if weekend_flat and not close_hit and not protect_hit:
            alert(f"{symbol}: Weekend flatten — closing before Friday FX close (avoid weekend gap)")

        if close_hit or weekend_flat or protect_hit:
            if _position_close_identity(pos) is None:
                logger.error(
                    "%s: protective close withheld — position side or size is uncertain",
                    symbol,
                )
                log_decision_skip(
                    symbol=symbol,
                    reason=PROTECTIVE_CLOSE_FAILED,
                    stage="position",
                    detail="uncertain_position",
                )
                return
            mh = _min_position_hold_sec()
            if (
                close_hit
                and not weekend_flat
                and not protect_hit
                and mh > 0
                and (time.time() - float(pos.open_time)) < mh
            ):
                logger.debug(
                    "%s: SL/TP touched but min hold %.0fs not met (age=%.1fs)",
                    symbol,
                    mh,
                    time.time() - float(pos.open_time),
                )
                _audit_reject("POSITION_MIN_HOLD", stage="position")
                return
            fill_path = close_fill_path(symbol, pos.execution_kind)
            if fill_path == "abort_broker_disabled":
                if protect_hit:
                    mark_protection_close_attempt(pos)
                alert(
                    f"{symbol}: Skip close — live position requires a broker fill but "
                    f"EXECUTION_MODE/USE_OANDA_LIVE is not sending orders (fail closed)"
                )
                logger.error("%s: live close aborted — broker orders disabled", symbol)
                _audit_reject("CLOSE_BROKER_DISABLED", stage="position")
                return

            spr_c: float | None
            slp_c: float | None
            impact_amt: float
            exit_price_exec: float | None
            lat_ms: int

            if fill_path == "simulate":
                if raw is None or price is None:
                    logger.error(
                        "%s: paper close not priced — decision candles unavailable",
                        symbol,
                    )
                    log_decision_skip(
                        symbol=symbol,
                        reason=MANAGEMENT_QUOTE_UNAVAILABLE,
                        stage="position",
                    )
                    _audit_reject("CLOSE_UNPRICED", stage="position")
                    return
                # SIMULATION CONTROL START
                lat_ms = await apply_latency()
                route_lb = _env_int("HYBRID_ROUTE_LOOKBACK", 60)
                df_px = compute_indicators(raw, lookback=route_lb)
                atr_v = float(df_px["atr"].iloc[-1])
                if math.isnan(atr_v) or atr_v <= 0:
                    atr_v = 0.0001
                strat_style = strategy_execution_style(pos.strategy_name)
                exit_leg = "SELL" if pos.direction == "BUY" else "BUY"
                mid_impact, impact_amt = apply_market_impact(pos.units, price, exit_leg)
                exit_price_exec, spr_c, slp_c = apply_execution_costs(
                    symbol, exit_leg, mid_impact, atr_v, strat_style
                )
                pnl = calculate_pnl(pos, exit_price_exec)
                alert(
                    f"[EXECUTION] {symbol} close latency={lat_ms}ms impact={impact_amt:.6f} "
                    f"spread={spr_c:.5f} slippage={slp_c:.5f}"
                )
                # SIMULATION CONTROL END
            else:
                lat_ms = 0
                spr_c, slp_c = None, None
                impact_amt = 0.0
                if price is None:
                    if fill_path != "broker":
                        logger.error(
                            "%s: protective close not priced — management price unavailable",
                            symbol,
                        )
                        log_decision_skip(
                            symbol=symbol,
                            reason=MANAGEMENT_QUOTE_UNAVAILABLE,
                            stage="position",
                        )
                        _audit_reject("CLOSE_UNPRICED", stage="position")
                        return
                    exit_price_exec = None
                    pnl = 0.0
                    alert(
                        f"[EXECUTION] BROKER_CLOSE {symbol} source={price_source} (PositionClose)"
                    )
                else:
                    exit_price_exec = float(price)
                    pnl = calculate_pnl(pos, exit_price_exec)
                    if fill_path == "broker":
                        alert(
                            f"[EXECUTION] BROKER_CLOSE {symbol} current={float(price):.5f} "
                            f"source={price_source} (PositionClose)"
                        )
                    else:
                        alert(
                            f"[EXECUTION] MID {symbol} close mid={float(price):.5f} "
                            f"(paper/window_paper; no broker order)"
                        )

            if protect_hit:
                mark_protection_close_attempt(pos)
            close_reason = "sl_tp" if sl_tp_hit else (
                "weekend_flatten" if weekend_flat and not protect_hit else (
                    "profit_protection" if protect_hit else "close"
                )
            )
            trigger = (
                "sl_tp_hit" if sl_tp_hit else (
                    "weekend_flat" if weekend_flat and not protect_hit else (
                        "protect_hit" if protect_hit else "close"
                    )
                )
            )
            logger.info(
                format_close_decision_line(
                    symbol=symbol,
                    broker_id=str(getattr(pos, "broker_order_id", "") or ""),
                    reason=close_reason,
                    entry=float(pos.entry_price),
                    current_price=None if price is None else float(price),
                    price_source=price_source if pos else PRICE_SOURCE_PAPER_CANDLE,
                    sl=float(pos.stop_loss),
                    tp=float(pos.take_profit),
                    mfe_pips=float(getattr(pos, "max_profit_pips", 0.0) or 0.0),
                    tp_progress=_tp_progress(pos),
                    protected_exit_pips=getattr(pos, "profit_protection_exit_pips", None),
                    trigger=trigger,
                    sl_tp_hit=sl_tp_hit,
                    weekend_flat=weekend_flat,
                    protect_hit=protect_hit,
                    current_side=pos.direction,
                )
            )
            diagnostics = None
            try:
                from forex_bot.trade_diagnostics import snapshot_from_position

                diagnostics = snapshot_from_position(
                    pos, exit_reason=close_reason, exit_price=exit_price_exec
                )
            except Exception:
                logger.exception("%s: trade diagnostics snapshot failed (ignored)", symbol)
            _audit_close(outcome="CLOSE_INTENT", trigger=close_reason, evidence="NOT_EVALUATED")
            _audit_close(outcome="CLOSE_SUBMISSION_ATTEMPTED", trigger=close_reason, evidence="NOT_EVALUATED")
            try:
                pnl = await execute_trade(
                    pos.symbol,
                    pos.strategy_name,
                    pos.direction,
                    pos.units,
                    pos.entry_price,
                    pos.stop_loss,
                    pos.take_profit,
                    realized_pnl=pnl,
                    execution_kind=pos.execution_kind,
                    exit_price=exit_price_exec,
                    spread_component=spr_c,
                    slippage_component=slp_c,
                    diagnostics=diagnostics,
                )
            except Exception as exc:
                close_diag = _close_exception_reason(exc)
                logger.exception("%s: close execution/logging failed (%s)", symbol, close_diag)
                log_decision_skip(symbol=symbol, reason=close_diag, stage="position")
                _audit_reject("CLOSE_FAILED", stage="position")
                _audit_close(
                    outcome="CLOSE_UNCONFIRMED" if close_diag == PROTECTIVE_CLOSE_UNCONFIRMED else "CLOSE_FAILED",
                    trigger=close_reason,
                    evidence="execute_trade_exception",
                )
                return
            close_position(symbol)
            if fill_path == "broker":
                _audit_close(
                    outcome="CLOSE_ACKNOWLEDGED",
                    trigger=close_reason,
                    evidence="execute_trade_returned",
                )
            else:
                _audit_close(outcome="CLOSE_EXECUTED", trigger=close_reason, evidence="local_fill")
            rl_agent.update(pos.rl_state, pos.direction, pnl)
            try:
                from forex_bot.decision_repair.flags import rl_persist_enabled
                from forex_bot.decision_repair.rl_store import RLStore, research_path

                if rl_persist_enabled():
                    RLStore(research_path()).save(
                        rl_agent.q,
                        alpha=rl_agent.alpha,
                        epsilon=rl_agent.epsilon,
                        mode="training",
                    )
            except Exception:
                logger.exception("RL persist failed (ignored; live gate unchanged)")
            logger.info(
                "[CLOSE] %s | Dir=%s | Units=%.4f | PnL=%.5f | entry=%.5f exit=%.5f | "
                "state=%s | reason=%s",
                symbol,
                pos.direction,
                pos.units,
                pnl,
                pos.entry_price,
                exit_price_exec if exit_price_exec is not None else float("nan"),
                pos.rl_state,
                close_reason,
            )
        return

    if raw is None or price is None:
        _skip_new_entry_without_candles(symbol, candle_audit or NO_OHLCV)
        return

    from forex_bot.broker_exit import broker_exit_open_blocked_reason

    pending_exit = broker_exit_open_blocked_reason(symbol)
    if pending_exit:
        logger.warning("%s: new entry blocked — %s", symbol, pending_exit)
        log_decision_skip(
            symbol=symbol, reason=RECONCILE_OR_PRETRADE_BLOCKED, stage="pretrade", detail=pending_exit
        )
        return

    blocked = pre_trade_entry_blocked_reason()
    if blocked:
        logger.warning("%s: new entry blocked — %s", symbol, blocked)
        skip_code = (
            LIVE_ORDER_AUTH_BLOCKED
            if str(blocked).startswith("live_order_auth")
            else RECONCILE_OR_PRETRADE_BLOCKED
        )
        log_decision_skip(symbol=symbol, reason=skip_code, stage="pretrade", detail=blocked)
        return

    route_lookback = _env_int("HYBRID_ROUTE_LOOKBACK", 60)
    df_route = compute_indicators(raw, lookback=route_lookback)

    strategy_name, lookback, horizon = select_strategy(symbol, df_route)
    try:
        from forex_bot.decision_repair.flags import deterministic_select_enabled
        from forex_bot.decision_repair.selection import last_selection

        sel = last_selection() if deterministic_select_enabled() else None
    except Exception:
        sel = None
    _safe_audit(
        symbol=symbol,
        selected_strategy=strategy_name,
        selection_policy_version=(
            sel.policy_version
            if sel is not None
            else (
                "deterministic_v1_unvalidated"
                if (os.getenv("DECISION_REPAIR_DETERMINISTIC_SELECT") or "").strip()
                else "legacy_random"
            )
        ),
        candidates=[c.name for c in sel.candidates] if sel is not None else "NOT_EVALUATED",
        candidate_eligibility=(
            [
                {
                    "name": c.name,
                    "eligible": c.eligible,
                    "active": c.active,
                    "reason": c.reject_reason,
                }
                for c in sel.candidates
            ]
            if sel is not None
            else "NOT_EVALUATED"
        ),
        strategy_activation_state=(
            "active" if strategy_name and strategies[strategy_name].active else "inactive"
        ),
        final_decision="pending",
    )
    if strategy_name is None:
        log_strategy_pre_sizing_skip(
            symbol=symbol,
            reason=NO_STRATEGY_SELECTED,
            selected=None,
            lookback=lookback,
            horizon=horizon,
        )
        return
    strat = strategies[strategy_name]
    if not strat.active:
        log_strategy_pre_sizing_skip(
            symbol=symbol,
            reason=STRATEGY_INACTIVE,
            selected=strategy_name,
            lookback=lookback,
            horizon=horizon,
        )
        return
    from forex_bot.live_safety import live_safety_initialised

    if live_safety_initialised() and not bool(getattr(strat, "authorised_for_live", False)):
        log_strategy_pre_sizing_skip(
            symbol=symbol,
            reason=STRATEGY_NOT_AUTHORISED,
            selected=strategy_name,
            lookback=lookback,
            horizon=horizon,
        )
        return

    try:
        df = compute_indicators(raw, lookback=lookback)
    except Exception:
        logger.exception("%s: indicator calculation failed", symbol)
        log_decision_skip(symbol=symbol, reason=STALE_OR_INVALID_DATA, stage="quant")
        _audit_reject("INDICATOR_CALCULATION_FAILURE", stage="quant")
        return
    if df is None or getattr(df, "empty", True):
        log_decision_skip(symbol=symbol, reason=STALE_OR_INVALID_DATA, stage="quant")
        _audit_reject("INDICATOR_CALCULATION_FAILURE", stage="quant")
        return
    if not volatility_ok(df):
        alert(f"{symbol}: Volatility outside safe range, skipping trade")
        log_decision_skip(symbol=symbol, reason=VOLATILITY_UNSAFE, stage="quant")
        return

    price = float(df["close"].iloc[-1])
    seq_model.update(symbol, price)
    seq_pred = seq_model.predict(symbol)
    nn_pred = compute_nn_pred(price, seq_pred)

    ma_fast = float(df["ma_fast"].iloc[-1])
    ma_slow = float(df["ma_slow"].iloc[-1])
    atr_v = float(df["atr"].iloc[-1])
    ret_1 = float(df["close"].pct_change().iloc[-1]) if len(df) > 1 else 0.0

    ai_decision = await ai.vote(
        {
            "symbol": symbol,
            "strategy": strategy_name,
            "price": price,
            "nn_pred": nn_pred,
            "seq_pred": seq_pred,
            "horizon": horizon,
            "lookback": lookback,
            "hybrid": horizon != "legacy",
            "ma_fast": ma_fast,
            "ma_slow": ma_slow,
            "sma_fast": ma_fast,
            "sma_slow": ma_slow,
            "returns": ret_1,
            "atr": atr_v,
            "timeframe": "M5",
            "m5_bar_time": _m5_bar_time(raw),
        },
        symbol,
    )
    if not isinstance(ai_decision, dict) or "allow" not in ai_decision:
        log_decision_skip(
            symbol=symbol,
            reason=QUANT_AI_REJECTED,
            stage="quant_ai",
            strategy=strategy_name,
        )
        _safe_audit(ai_vote="UNAVAILABLE", ai_model_id="UNAVAILABLE")
        return
    _safe_audit(
        ai_vote=ai_decision.get("direction") or "UNAVAILABLE",
        ai_confidence=ai_decision.get("confidence"),
        ai_model_id=str(ai_decision.get("model") or "ensemble"),
    )
    if not ai_decision["allow"]:
        log_decision_skip(
            symbol=symbol,
            reason=QUANT_AI_REJECTED,
            stage="quant_ai",
            strategy=strategy_name,
        )
        return

    trend_v = float(df["trend"].iloc[-1])
    vol_v = float(df["volatility"].iloc[-1])
    if math.isnan(trend_v):
        trend_v = 0.0
    if math.isnan(vol_v):
        vol_v = 0.0
    state = f"{round(trend_v, 4)}_{round(vol_v, 6)}"

    # RL is a gate: SKIP blocks; BUY/SELL must agree with AI (never override AI side).
    direction = str(ai_decision.get("direction", "BUY")).upper().strip()
    if direction not in ("BUY", "SELL"):
        direction = "BUY"
    rl_action = rl_agent.decide(state)
    _safe_audit(
        rl_action=rl_action,
        rl_state_fingerprint=state,
        rl_model_id="tabular_q_v1",
    )
    if rl_action == "UNAVAILABLE":
        logger.info("%s: RL state unavailable — blocking decision", symbol)
        log_decision_skip(symbol=symbol, reason=RL_STATE_UNAVAILABLE, stage="rl", state=state)
        _safe_audit(
            symbol=symbol,
            selected_strategy=strategy_name,
            rl_action="UNAVAILABLE",
            final_decision="reject",
            rejection_reasons=[RL_STATE_UNAVAILABLE],
        )
        return
    try:
        _observe_v2_shadow_candidate(
            symbol=symbol,
            strategy_name=strategy_name,
            direction=direction,
            price=price,
            df=df,
            atr_v=atr_v,
            ma_fast=ma_fast,
            ma_slow=ma_slow,
            ret_1=ret_1,
            rl_action=rl_action,
            rl_state=state,
        )
    except Exception:
        logger.exception("[V2 SHADOW] observe failed (ignored)")
    if rl_action == "SKIP":
        logger.info("%s: RL decided to skip trade (state=%s)", symbol, state)
        log_decision_skip(symbol=symbol, reason=RL_SKIP, stage="rl", state=state)
        return
    if rl_action in ("BUY", "SELL") and rl_action != direction:
        logger.info(
            "%s: RL gate blocked (rl=%s ai=%s state=%s)",
            symbol,
            rl_action,
            direction,
            state,
        )
        log_decision_skip(
            symbol=symbol,
            reason=RL_DIRECTION_MISMATCH,
            stage="rl",
            rl=rl_action,
            ai=direction,
        )
        return
    confidence = float(ai_decision.get("confidence", 0.6))

    weight = portfolio.get_weight(symbol)
    atr_v = float(df["atr"].iloc[-1])
    if math.isnan(atr_v) or atr_v <= 0:
        atr_v = 0.0001
    strat_style = strategy_execution_style(strategy_name)
    sl_d, tp_d = sl_tp_distance_for_entry(symbol, atr_v)
    stop_mid = price - sl_d if direction == "BUY" else price + sl_d

    balance = current_equity()
    units = position_sizing(symbol, price, stop_mid, balance)
    if notional_pct_of_nav() <= 0:
        units *= weight * confidence
    units = cap_position_units(units)
    if notional_pct_of_nav() > 0:
        units = math.floor(float(units) + 1e-9)
        if units < 1:
            logger.info(
                "%s: skip — per-trade notional size rounds below 1 OANDA unit (NAV=%.2f)",
                symbol,
                balance,
            )
            log_decision_skip(symbol=symbol, reason=SIZING_BELOW_MIN, stage="sizing")
            return
        logger.info(
            "[SIZE] %s units=%.0f notional≈%.2f USD (per-trade %.2f%% of NAV %.2f; "
            "portfolio cap %.2f%% ≈ %.2f USD)",
            symbol,
            units,
            approx_gross_usd_notional_for(symbol, float(units), float(price)),
            notional_pct_of_nav() * 100.0,
            balance,
            portfolio_gross_notional_pct_of_nav() * 100.0,
            configured_max_gross_usd(),
        )

    # MICRO_STRATEGY / LOT_SIZE HOOK START (optional — uncomment and implement)
    # sym_u = symbol.upper().replace("-", "_")
    # _lot = (os.getenv(f"LOT_SIZE_OVERRIDE_{sym_u}") or "").strip()
    # if _lot:
    #     units = max(1.0, float(_lot))
    # _micro = (os.getenv(f"MICRO_STRATEGY_{sym_u}") or "").strip()
    # if _micro:
    #     pass  # e.g. scale units or gate entries by label (scalp_1h, etc.)
    # MICRO_STRATEGY / LOT_SIZE HOOK END

    if units < 1e-6:
        log_decision_skip(symbol=symbol, reason=SIZING_BELOW_MIN, stage="sizing")
        return

    if pre_close_adjustment(symbol):
        alert(f"{symbol}: Near session close, reducing position size by 50%")
        units *= 0.5
        if units < 1.0:
            _audit_reject(SIZING_BELOW_MIN, stage="sizing")
            return

    alert(
        f"[HYBRID] {symbol} | horizon={horizon} | lookback={lookback} | "
        f"strategy={strategy_name} | route_lb={route_lookback}"
    )

    # live_allowed = is_live_trading(symbol, use_scalp_window=True)
    # LIVE WINDOW CHECK START
    live_allowed = is_live_trading(symbol)
    paper = effective_paper_trading()
    fill_path = open_fill_path(symbol)
    if fill_path == "abort_broker_disabled":
        alert(
            f"{symbol}: Skip open — inside live window but broker orders are disabled "
            f"(set EXECUTION_MODE=live_broker or paper_broker; fail closed, no local live fill)"
        )
        logger.error("%s: live open aborted — broker orders disabled", symbol)
        _audit_reject("BROKER_ORDERS_DISABLED", stage="pretrade")
        return
    use_live_fill = fill_path == "broker"
    if use_live_fill:
        exec_kind = "live"
    else:
        exec_kind = "simulated" if paper else "window_paper"

    if is_paper_like_kind(exec_kind):
        from forex_bot.reconciliation import paper_open_blocked_reason

        skip_why = paper_open_blocked_reason(symbol)
        if skip_why:
            logger.warning("[PAPER SKIP] %s | %s", symbol, skip_why)
            _audit_reject("PAPER_OPEN_BLOCKED", stage="pretrade")
            return

    use_sim_layers = fill_path == "simulate"
    if live_window_log_enabled():
        win = symbol_live_window_status(symbol)
        logger.info(
            "[LIVE WINDOW] %s %s → exec=%s | local=%s %s | utc=%s | now_local=%s | now_utc=%s | "
            "tz=%s offset=%s | paper=%s",
            symbol,
            "IN" if live_allowed else "OUT",
            exec_kind,
            win["local_window"],
            win["dst_label"],
            win["utc_window"],
            win["now_local"],
            win["now_utc"],
            win["timezone"],
            win["utc_offset"],
            paper,
        )
    # QUOTA: future per-symbol daily caps should run only when use_sim_layers is True
    # LIVE WINDOW CHECK END

    if not use_live_fill and not paper:
        win = symbol_live_window_status(symbol)
        alert(
            f"{symbol}: Outside live window — local {win['local_window']} {win['dst_label']} "
            f"(UTC {win['utc_window']}); now {win['now_local']} {win['dst_label']} / "
            f"{win['now_utc']} UTC — paper-style fills until the window opens "
            f"(hybrid/AI/RL unchanged)"
        )

    approx_add = approx_gross_usd_notional_for(symbol, float(units), float(price))
    cap_decision = notional_cap_decision(approx_add)
    acct = last_account_summary()
    ccy = str(acct.get("currency") or "")
    nav = acct.get("NAV")
    if cap_decision["exceeds"]:
        msg = format_notional_cap_skip_alert(
            symbol, cap_decision, nav=nav, currency=ccy, direction=direction
        )
        alert(msg)
        logger.warning("%s", msg)
        _audit_reject("NOTIONAL_CAP", stage="risk")
        return
    logger.info(
        "%s",
        format_notional_cap_report(
            symbol, cap_decision, nav=nav, currency=ccy, allowed=True, direction=direction
        ),
    )

    # Stop risk in account currency (handles USD_* quote conversion).
    new_risk_at_stop = stop_risk_account_ccy(symbol, float(price), float(sl_d), float(units))
    if portfolio_risk_cap_exceeded(current_equity(), new_risk_at_stop):
        eq = current_equity()
        open_risk = portfolio_risk_amount()
        projected = open_risk + float(new_risk_at_stop)
        cap_pct = configured_max_portfolio_risk_pct()
        cap_amt = max(0.0, float(eq)) * cap_pct
        alert(
            f"{symbol}: Skip open — portfolio stop risk cap\n"
            f"Candidate symbol: {symbol}\n"
            f"Candidate side: {direction}\n"
            f"Current stop-risk exposure: {open_risk:.2f}\n"
            f"Projected stop-risk exposure: {projected:.2f}\n"
            f"Configured cap: {cap_amt:.2f} ({cap_pct * 100:.2f}% of equity {eq:.2f})\n"
            f"Rejection reason: projected stop risk exceeds MAX_PORTFOLIO_RISK_PCT"
        )
        _audit_reject("PORTFOLIO_RISK_CAP", stage="risk")
        return

    usd_dir_decision = usd_direction_guard_decision(symbol, direction)
    if usd_dir_decision["exceeds"]:
        msg = format_usd_direction_skip(usd_dir_decision)
        alert(msg)
        logger.warning("%s", msg)
        _audit_reject("USD_DIRECTION_GUARD", stage="risk")
        return

    entry_price: float
    spread_amt: float
    slip_amt: float
    position_units: float = float(units)

    broker_oid = ""
    client_order_id = ""
    fill_ts: float | None = None
    if fill_path == "broker":
        from forex_bot.market_provenance import decision_frame_rejection

        frame_reason = decision_frame_rejection(raw, symbol)
        if frame_reason:
            logger.warning("%s: refuse broker open — market provenance %s", symbol, frame_reason)
            log_decision_skip(
                symbol=symbol,
                reason=STALE_OR_INVALID_DATA,
                stage="provenance",
                detail=frame_reason,
            )
            return
        if is_paper_like_kind(exec_kind):
            logger.error(
                "%s: refuse broker open — fill_path=broker but exec_kind=%s",
                symbol,
                exec_kind,
            )
            _audit_reject("BROKER_KIND_MISMATCH", stage="broker")
            return
        client_order_id = generate_client_order_id()
        t_reserve = time.perf_counter()
        if not try_begin_order_submission(
            client_order_id=client_order_id,
            symbol=symbol,
            direction=direction,
            units=float(units),
            metadata={"mid": float(price), "strategy": strategy_name},
        ):
            logger.warning("%s: idempotent skip — duplicate client_order_id or DB conflict", symbol)
            _audit_reject("IDEMPOTENT_SKIP", stage="broker")
            return
        t_sent = time.perf_counter()
        # Live/paper_broker: attach SL/TP to a fresh executable bid/ask, not M5 mid.
        # Cycle snapshot is stale; dedicated PricingInfo GET immediately before OrderCreate.
        if not live_broker_geometry_required(fill_path):
            mark_order_failed_or_cancelled(client_order_id)
            logger.error("%s: refuse broker open — fill_path=%s is not broker", symbol, fill_path)
            _audit_reject("FILL_PATH_NOT_BROKER", stage="broker")
            return
        fetched = fetch_entry_pricing(symbol)
        if fetched.skip_reason is not None:
            mark_order_failed_or_cancelled(client_order_id)
            msg = format_entry_geometry_skip(symbol, direction, fetched.skip_reason)
            logger.warning("%s", msg)
            alert(msg)
            log_decision_skip(
                symbol=symbol,
                reason=STALE_OR_INVALID_DATA,
                stage="entry_geometry",
                detail=fetched.skip_reason,
            )
            return
        geom, skip_reason = resolve_live_entry_geometry(
            symbol,
            direction,
            float(sl_d),
            float(tp_d),
            float(price),
            quote=fetched.quote,
            atr=atr_v,
            request_duration_ms=fetched.request_duration_ms,
            fetch_age_ms=fetched.fetch_age_ms(),
        )
        if skip_reason is not None:
            mark_order_failed_or_cancelled(client_order_id)
            msg = format_entry_geometry_skip(
                symbol, direction, skip_reason or "unknown", geom=geom
            )
            logger.warning("%s", msg)
            alert(msg)
            log_decision_skip(
                symbol=symbol,
                reason=STALE_OR_INVALID_DATA,
                stage="entry_geometry",
                detail=skip_reason,
            )
            return
        if geom is None:
            mark_order_failed_or_cancelled(client_order_id)
            msg = format_entry_geometry_skip(symbol, direction, "unknown")
            logger.warning("%s", msg)
            alert(msg)
            log_decision_skip(symbol=symbol, reason=STALE_OR_INVALID_DATA, stage="entry_geometry")
            return
        logger.info("%s", format_entry_geometry_line(geom))
        broker_sl = float(geom.sl)
        broker_tp = float(geom.tp)
        if not _permit_new_exposure_or_block():
            mark_order_failed_or_cancelled(client_order_id)
            logger.error("%s: new exposure blocked — required audit write failed", symbol)
            _audit_reject("AUDIT_WRITE_FAILED", stage="audit")
            return
        _safe_audit(
            client_order_id=client_order_id,
            order_intent_id=client_order_id,
            submission_status="attempted",
            path="new_entry",
        )
        try:
            fill_price, filled_u, oid, _pl, fill_ts = await oanda_exec.execute_oanda_market_open(
                symbol,
                units,
                direction,
                client_order_id,
                stop_loss=broker_sl,
                take_profit=broker_tp,
                execution_kind=exec_kind,
                entry_quote=fetched.quote,
            )
        except oanda_exec.OrderCreateCancelled as exc:
            record_fill_failure()
            mark_order_failed_or_cancelled(client_order_id)
            logger.warning("%s", exc)
            _audit_reject("BROKER_SUBMISSION_CANCELLED", stage="broker")
            _safe_audit(order_submitted=True, broker_ack=False, submission_status="cancelled")
            return
        except oanda_exec.OrderCreateOutcomeError as exc:
            record_fill_failure()
            mark_order_failed_or_cancelled(client_order_id)
            logger.warning("[ORDER FAILED] %s open: %s", symbol, exc)
            _audit_reject("BROKER_SUBMISSION_FAILED", stage="broker")
            _safe_audit(order_submitted=True, broker_ack=False, submission_status="failed")
            return
        except Exception as exc:
            record_fill_failure()
            mark_order_failed_or_cancelled(client_order_id)
            logger.warning("[ORDER FAILED] %s open: %s", symbol, exc)
            _audit_reject("BROKER_SUBMISSION_FAILED", stage="broker")
            _safe_audit(order_submitted=True, broker_ack=False, submission_status="failed")
            return
        _safe_audit(
            order_submitted=True,
            broker_ack=True,
            submission_status="acknowledged",
            broker_request_id=str(oid or ""),
            client_order_id=client_order_id,
            final_decision="order_ack",
        )
        t_fill = time.perf_counter()
        entry_price = float(fill_price)
        spread_amt = 0.0
        slip_amt = 0.0
        impact_amt = 0.0
        st = OrderStatus.FILLED
        if float(filled_u) + 1e-6 < float(units):
            st = OrderStatus.PARTIAL
            logger.info("[ORDER PARTIAL] %s filled=%.4f requested=%.4f", symbol, filled_u, units)
        position_units = float(filled_u)
        broker_oid = str(oid) if oid else ""
        finalize_order_fill(
            client_order_id,
            broker_order_id=str(oid) if oid else "",
            fill_price=entry_price,
            units_filled=float(filled_u),
            status=st,
            metadata={
                "expected_mid": float(price),
                "executable_reference": float(geom.executable_reference),
                "submitted_sl": broker_sl,
                "submitted_tp": broker_tp,
                "slippage_signed": (entry_price - float(price))
                if direction == "BUY"
                else (float(price) - entry_price),
            },
        )
        record_fill_quality(
            expected_price=float(geom.executable_reference),
            fill_price=entry_price,
            direction=direction,
            latency_signal_to_send_ms=(t_sent - t_reserve) * 1000.0,
            latency_send_to_fill_ms=(t_fill - t_sent) * 1000.0,
        )
        logger.info(
            "%s",
            format_entry_fill_geometry_line(
                symbol=symbol,
                side=direction,
                reference=float(geom.executable_reference),
                fill=entry_price,
                sl=broker_sl,
                tp=broker_tp,
                broker_id=broker_oid,
                transaction_id=str(oid or ""),
            ),
        )
        alert(
            f"[EXECUTION] BROKER_FILL {symbol} open fill={entry_price:.5f} units≈{filled_u:.4f} id={oid} cid={client_order_id}"
        )
    elif use_sim_layers:
        if not _permit_new_exposure_or_block():
            logger.error("%s: new exposure blocked — required audit write failed", symbol)
            _audit_reject("AUDIT_WRITE_FAILED", stage="audit")
            return
        _safe_audit(submission_status="internal_open", order_submitted=False, simulated=True)
        # SIMULATION CONTROL START
        lat_ms = await apply_latency()
        mid_impact, impact_amt = apply_market_impact(units, price, direction)
        entry_price, spread_amt, slip_amt = apply_execution_costs(
            symbol, direction, mid_impact, atr_v, strat_style
        )
        alert(
            f"[EXECUTION] {symbol} open latency={lat_ms}ms impact={impact_amt:.6f} "
            f"spread={spread_amt:.5f} slippage={slip_amt:.5f}"
        )
        # SIMULATION CONTROL END
    else:
        if not _permit_new_exposure_or_block():
            logger.error("%s: new exposure blocked — required audit write failed", symbol)
            _audit_reject("AUDIT_WRITE_FAILED", stage="audit")
            return
        _safe_audit(submission_status="internal_open", order_submitted=False, simulated=True)
        entry_price = float(price)
        spread_amt = 0.0
        slip_amt = 0.0
        impact_amt = 0.0
        alert(
            f"[EXECUTION] MID {symbol} open mid={price:.5f} "
            f"(paper/window_paper; no broker order; live_allowed={live_allowed} exec_kind={exec_kind})"
        )

    if direction == "BUY":
        stop_loss = entry_price - sl_d
        take_profit = entry_price + tp_d
    else:
        stop_loss = entry_price + sl_d
        take_profit = entry_price - tp_d

    atr_entry = None
    try:
        from forex_bot.indicators import latest_atr_price
        from forex_bot.profit_protection import atr_to_pips, profit_protection_atr_period

        atr_px = latest_atr_price(raw, profit_protection_atr_period())
        if atr_px is not None:
            atr_entry = atr_to_pips(symbol, atr_px)
    except Exception:
        logger.exception("%s: ATR-at-entry snapshot failed (ignored)", symbol)
    if fill_path == "broker" and fill_ts:
        opened_at = float(fill_ts)
    else:
        opened_at = datetime.utcnow().timestamp()
    open_position(
        Position(
            symbol=symbol,
            direction=direction,
            units=float(position_units),
            entry_price=entry_price,
            stop_loss=stop_loss,
            take_profit=take_profit,
            open_time=opened_at,
            strategy_name=strategy_name,
            rl_state=state,
            execution_kind=exec_kind,
            atr_at_entry_pips=atr_entry,
            client_order_id=client_order_id,
            broker_order_id=broker_oid,
            broker_order=fill_path == "broker",
            max_profit_pips=0.0,
            profit_protection_seeded=fill_path == "broker",
        )
    )
    if fill_path == "broker":
        alert(
            f"[OPEN] {symbol} {direction} units={position_units:.2f} entry={entry_price:.5f} "
            f"mid={price:.5f} SL={stop_loss:.5f} TP={take_profit:.5f} kind={exec_kind} "
            f"broker_order=true cid={client_order_id} broker_id={broker_oid} "
            f"strategy={strategy_name} horizon={horizon}"
        )
    else:
        alert(
            f"[OPEN] {symbol} {direction} units={position_units:.2f} entry={entry_price:.5f} "
            f"mid={price:.5f} SL={stop_loss:.5f} TP={take_profit:.5f} kind={exec_kind} "
            f"broker_order=false strategy={strategy_name} horizon={horizon}"
        )
    logger.info(
        "[AI+RL] %s | OPEN Dir=%s | Units=%.4f | Conf=%.2f | RL_Action=%s | State=%s | %s lb=%s",
        symbol,
        direction,
        position_units,
        confidence,
        rl_action,
        state,
        horizon,
        lookback,
    )


def evolve() -> None:
    from forex_bot.decision_repair.flags import health_enabled

    if health_enabled():
        from forex_bot.decision_repair.health import record_evaluation

        record_evaluation(
            pnl_by_name={name: list(strat.pnl) for name, strat in strategies.items()},
            operator_disabled={name: not bool(strat.active) for name, strat in strategies.items()},
        )
        return
    for name, strat in strategies.items():
        if len(strat.pnl) < 20:
            continue
        if strat.sharpe() < 0:
            strat.active = False
            logger.info("Strategy disabled (sharpe < 0): %s", name)
            try:
                from forex_bot.live_safety import persist_evolve_disable

                persist_evolve_disable(name, sample_count=len(strat.pnl), sharpe=float(strat.sharpe()))
            except Exception:
                logger.exception("persist evolve disable failed for %s (strategy remains inactive)", name)


def daily_report() -> None:
    """Emit DAILY REPORT alert at most once per ``DAILY_REPORT_INTERVAL_SEC`` (default 86400 = 24h). Set 0 to disable."""
    try:
        interval = float((os.getenv("DAILY_REPORT_INTERVAL_SEC") or "86400").strip() or "86400")
    except ValueError:
        interval = 86400.0
    if interval <= 0:
        return
    now = time.time()
    last = last_report_ts()
    if last is not None and (now - last) < interval:
        return
    set_last_report_ts(now)
    eq = current_equity()
    alert(
        f" DAILY REPORT: Equity={eq:.2f} Sharpe={analytics.sharpe():.2f} "
        f"Winrate={analytics.winrate():.2%} Drawdown={analytics.drawdown():.2f}"
    )


async def run_bot() -> None:
    while True:
        try:
            # Reconciliation runs in app.reconciliation_loop only (avoid concurrent mutation).
            await asyncio.to_thread(fetch_account_summary)
            await asyncio.to_thread(_refresh_pricing_snapshot)
            await _cycle_symbols(Config.SYMBOLS)
            state_dict["last_bot_cycle_utc"] = datetime.now(timezone.utc).isoformat()
            record_operational_transition_if_changed()
            portfolio.update(
                {
                    "equity": current_equity(),
                    "sharpe": analytics.sharpe(),
                    "drawdown": analytics.drawdown(),
                    "winrate": analytics.winrate(),
                    "win_rate_pct": analytics.win_rate_pct(),
                }
            )
            if live_window_log_enabled():
                log_live_windows(reason="cycle")
            _maybe_log_performance_metrics()
            evolve()
            daily_report()
        except Exception as exc:
            logger.exception("run_bot iteration error: %s", exc)
        await asyncio.sleep(Config.TRADE_INTERVAL)
