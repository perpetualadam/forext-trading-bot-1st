"""Single source of truth for execution profile (paper vs broker) and safety gates."""

from __future__ import annotations

import os
from datetime import datetime
from enum import Enum


class ExecutionMode(str, Enum):
    """How fills and broker orders are handled."""

    PAPER = "paper"
    PAPER_BROKER = "paper_broker"
    LIVE_BROKER = "live_broker"


# Local-only fill tags. Must never reach OANDA OrderCreate / PositionClose.
PAPER_LIKE_KINDS = frozenset({"paper", "simulated", "window_paper"})


def is_paper_like_kind(execution_kind: str | None) -> bool:
    return (execution_kind or "").strip().lower() in PAPER_LIKE_KINDS


BROKER_BACKED_KINDS = frozenset({"live", "reconcile_import"})


def is_paper_like(pos: object | None) -> bool:
    """True for local-only simulation rows (paper / simulated / window_paper)."""
    if pos is None:
        return False
    return is_paper_like_kind(getattr(pos, "execution_kind", None))


def is_broker_backed(pos: object | None) -> bool:
    """True for genuine broker/reconcile rows. Paper-like never counts, even if flags are messy."""
    if pos is None or is_paper_like(pos):
        return False
    kind = (getattr(pos, "execution_kind", None) or "").strip().lower()
    if kind in BROKER_BACKED_KINDS:
        return True
    return bool(getattr(pos, "broker_order", False))


_trading_halted: bool = False


def halt_trading() -> None:
    """In-process emergency stop (also use KILL_SWITCH env for startup)."""
    global _trading_halted
    _trading_halted = True


def resume_trading() -> None:
    global _trading_halted
    _trading_halted = False


def is_trading_halted_runtime() -> bool:
    return _trading_halted


def kill_switch_env_active() -> bool:
    return (os.getenv("KILL_SWITCH") or "").strip().lower() in ("1", "true", "yes", "on")


def trading_allowed() -> bool:
    """False blocks **new** risk only; closes may still run."""
    if _trading_halted:
        return False
    if kill_switch_env_active():
        return False
    return True


def strict_execution() -> bool:
    """When true, broker modes must not use random or missing-PnL fallbacks."""
    raw = (os.getenv("STRICT_EXECUTION") or "1").strip().lower()
    return raw not in ("0", "false", "no", "off")


def execution_mode_env_explicitly_set() -> bool:
    """True when ``EXECUTION_MODE`` is set to a known value (``PAPER_TRADING`` is ignored then)."""
    raw = (os.getenv("EXECUTION_MODE") or "").strip().lower()
    return raw in ("paper", "paper_broker", "live_broker")


def get_execution_mode() -> ExecutionMode:
    """
    Authoritative execution profile.

    **Precedence:** If ``EXECUTION_MODE`` is set to ``paper`` / ``paper_broker`` / ``live_broker``,
    it **fully overrides** legacy ``PAPER_TRADING`` for execution semantics. If unset, derive from
    ``PAPER_TRADING`` + ``TRADING_MODE`` (see below).

    - ``EXECUTION_MODE`` env wins when set to paper | paper_broker | live_broker.
    - Otherwise derive from legacy ``PAPER_TRADING`` + ``TRADING_MODE`` (OANDA host).
    """
    raw = (os.getenv("EXECUTION_MODE") or "").strip().lower()
    if raw == "paper":
        return ExecutionMode.PAPER
    if raw == "paper_broker":
        return ExecutionMode.PAPER_BROKER
    if raw == "live_broker":
        return ExecutionMode.LIVE_BROKER

    from forex_bot.config import Config

    paper = bool(getattr(Config, "PAPER_TRADING", True))
    if paper:
        return ExecutionMode.PAPER
    tm = (getattr(Config, "TRADING_MODE", None) or os.getenv("TRADING_MODE") or "practice").strip().lower()
    return ExecutionMode.LIVE_BROKER if tm == "live" else ExecutionMode.PAPER_BROKER


def effective_paper_trading() -> bool:
    """True when fully simulated (no broker order path). Replaces bare ``PAPER_TRADING`` checks."""
    return get_execution_mode() == ExecutionMode.PAPER


def is_broker_execution() -> bool:
    return get_execution_mode() in (ExecutionMode.PAPER_BROKER, ExecutionMode.LIVE_BROKER)


def is_live_broker() -> bool:
    return get_execution_mode() == ExecutionMode.LIVE_BROKER


def execution_mode_explicit() -> bool:
    """True if ``EXECUTION_MODE`` is set (dashboard-friendly name; same as ``execution_mode_env_explicitly_set``)."""
    return execution_mode_env_explicitly_set()


def pre_trade_entry_allowed() -> bool:
    """Single combined gate for **new** risk: kill switch / halt + reconcile + live auth.

    :mod:`forex_bot.operational_state` derives labels from this path; do not gate on those labels.
    """
    return pre_trade_entry_blocked_reason() is None


def pre_trade_entry_blocked_reason() -> str | None:
    if is_trading_halted_runtime():
        return "halt_runtime"
    if kill_switch_env_active():
        return "kill_switch_env"
    from forex_bot.live_safety import live_open_blocked_reason

    auth_block = live_open_blocked_reason()
    if auth_block:
        return auth_block
    from forex_bot.decision_repair.flags import account_risk_enabled

    if account_risk_enabled():
        from forex_bot.decision_repair.account_risk import block_reason
        from forex_bot.state import state as app_state

        nav = app_state.get("broker_nav")
        try:
            equity = float(nav) if nav is not None else None
        except (TypeError, ValueError):
            equity = None
        if "broker_unrealised_pl" in app_state:
            raw_upl = app_state.get("broker_unrealised_pl")
            try:
                unrealised = float(raw_upl) if raw_upl is not None else None
            except (TypeError, ValueError):
                unrealised = None
        else:
            unrealised = None
        risk_block = block_reason(equity=equity, unrealised=unrealised)
        if risk_block:
            return risk_block
        from forex_bot.decision_repair.exposure import (
            block_reason_for_snapshot,
            snapshot_from_broker_view,
        )

        if "broker_positions" not in app_state or "broker_pending_orders" not in app_state:
            return "exposure_snapshot_missing"
        snap = snapshot_from_broker_view(
            nav=equity,
            unrealised=unrealised if unrealised is not None else 0.0,
            positions=list(app_state.get("broker_positions") or []),
            pending_orders=list(app_state.get("broker_pending_orders") or []),
            reconcile_status=str(app_state.get("broker_reconcile_status") or "unknown"),
            stale=bool(app_state.get("broker_exposure_stale")),
        )
        exp_block = block_reason_for_snapshot(snap)
        if exp_block:
            return exp_block
    from forex_bot.reconciliation import reconcile_entry_blocked_reason

    return reconcile_entry_blocked_reason()


def broker_orders_enabled() -> bool:
    """True when the execution profile allows OANDA OrderCreate / PositionClose."""
    from forex_bot.oanda_exec import use_oanda_live

    return bool(use_oanda_live())


def open_fill_path(symbol: str, at_utc: datetime | None = None) -> str:
    """
    How a **new open** is filled.

    - ``broker`` — market order to OANDA (inside live window, not paper).
    - ``simulate`` — latency / impact / spread model (paper or off-window learning).
    - ``mid`` — local mid only (simulation layers forced off).
    - ``abort_broker_disabled`` — live window requires a broker fill but orders are off.
      Fail closed: never invent a local "live" fill.
    """
    from forex_bot.session_rules import is_live_trading, simulation_layers_enabled

    paper = effective_paper_trading()
    if (not paper) and is_live_trading(symbol, at_utc=at_utc):
        return "broker" if broker_orders_enabled() else "abort_broker_disabled"
    if simulation_layers_enabled(symbol, paper, at_utc=at_utc):
        return "simulate"
    return "mid"


def close_fill_path(symbol: str, execution_kind: str | None = None) -> str:
    """
    How a **close** is filled.

    Live-tagged positions always require a broker close (fail closed if orders are off),
    even after the live window ends. Paper / window_paper stay local.
    """
    kind = (execution_kind or "").strip().lower()
    if kind == "live":
        return "broker" if broker_orders_enabled() else "abort_broker_disabled"
    from forex_bot.session_rules import simulation_layers_enabled

    if simulation_layers_enabled(symbol, effective_paper_trading()):
        return "simulate"
    return "mid"
