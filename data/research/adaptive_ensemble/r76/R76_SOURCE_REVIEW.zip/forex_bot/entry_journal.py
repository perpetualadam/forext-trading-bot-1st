"""Durable entry intent. A permit is not entry authority and cannot close a position."""

from __future__ import annotations

import uuid
from decimal import Decimal
from typing import Any

from forex_bot.close_journal import (
    SCHEMA_VERSION,
    JournalUnavailable,
    _now,
    _units,
    active_journal,
)

ENTRY_RESERVED = "ENTRY_RESERVED"
ENTRY_SUBMITTING = "ENTRY_SUBMITTING"
ENTRY_FINALISED = "ENTRY_FINALISED"
_AMBIGUOUS_ON_RESTART = {
    ENTRY_RESERVED,
    ENTRY_SUBMITTING,
    "ENTRY_SENT",
}


class EntryGuardRefusal(RuntimeError):
    """The entry journal did not grant this submission. No order was sent."""


class EntrySubmissionPermit:
    """One-shot entry capability. Constructing it does not grant authority."""

    def __init__(
        self,
        *,
        operation_id: str,
        owner_token: str,
        account_binding: str,
        instrument: str,
        direction: str,
        requested_units: str,
        position_instance_id: str,
        position_generation: int,
        client_order_id: str,
    ) -> None:
        self.operation_id = operation_id
        self.owner_token = owner_token
        self.account_binding = account_binding
        self.instrument = instrument
        self.direction = direction
        self.requested_units = requested_units
        self.position_instance_id = position_instance_id
        self.position_generation = int(position_generation)
        self.client_order_id = client_order_id


def begin_entry_submission(
    *,
    account_binding_value: str,
    instrument: str,
    direction: str,
    requested_units: Decimal,
    position_instance_id: str,
    position_generation: int,
    client_order_id: str,
    strategy_name: str,
    stop_loss: str | None,
    take_profit: str | None,
    entry_reference: str | None,
    atr_at_entry_pips: str | None,
) -> EntrySubmissionPermit:
    """Commit reservation and submission intent. The caller may then claim once."""
    journal = active_journal()
    operation_id = uuid.uuid4().hex
    token = uuid.uuid4().hex
    units = _units(requested_units, required=True)
    stamp = _now()
    direction = direction.upper()
    with journal._lock:
        journal._begin()
        try:
            authorised = journal._conn.execute("SELECT closes_authorised FROM schema_meta WHERE id = 1").fetchone()
            if authorised is None or int(authorised[0]) != 1:
                journal._rollback()
                raise JournalUnavailable("bootstrap_does_not_authorise_closes")
            journal._conn.execute(
                """
                INSERT INTO entry_operations (
                    operation_id, owner_token, account_binding, instrument, direction,
                    requested_units, position_instance_id, position_generation, client_order_id,
                    strategy_name, stop_loss, take_profit, entry_reference, initial_max_profit_pips,
                    initial_protection_active, atr_at_entry_pips, submission_intent, network_permit,
                    submission_state, outcome, broker_order_id, broker_trade_id, transaction_ids,
                    recovery_status, error_classification, created_at, updated_at, schema_version
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, '0', 0, ?, 0, 0,
                          'NOT_SENT', ?, NULL, NULL, '', 'reserved', '', ?, ?, ?)
                """,
                (
                    operation_id,
                    token,
                    account_binding_value,
                    instrument,
                    direction,
                    units,
                    position_instance_id,
                    int(position_generation),
                    client_order_id,
                    strategy_name,
                    stop_loss,
                    take_profit,
                    entry_reference,
                    atr_at_entry_pips,
                    ENTRY_RESERVED,
                    stamp,
                    stamp,
                    SCHEMA_VERSION,
                ),
            )
            journal._commit()
        except JournalUnavailable:
            raise
        except Exception as exc:
            journal._rollback()
            if exc.__class__.__name__ == "IntegrityError":
                raise JournalUnavailable("unresolved_entry_exists") from exc
            raise JournalUnavailable("persistence_failure") from exc
    with journal._lock:
        journal._begin()
        try:
            cursor = journal._conn.execute(
                """
                UPDATE entry_operations
                   SET submission_intent = 1,
                       submission_state = 'SENDING',
                       outcome = ?,
                       updated_at = ?
                 WHERE operation_id = ?
                   AND owner_token = ?
                   AND submission_intent = 0
                   AND network_permit = 0
                   AND outcome = ?
                """,
                (ENTRY_SUBMITTING, _now(), operation_id, token, ENTRY_RESERVED),
            )
            if cursor.rowcount != 1:
                journal._rollback()
                raise JournalUnavailable("entry_intent_not_durable")
            journal._commit()
        except JournalUnavailable:
            raise
        except Exception as exc:
            journal._rollback()
            raise JournalUnavailable("persistence_failure") from exc
    return EntrySubmissionPermit(
        operation_id=operation_id,
        owner_token=token,
        account_binding=account_binding_value,
        instrument=instrument,
        direction=direction,
        requested_units=str(units),
        position_instance_id=position_instance_id,
        position_generation=int(position_generation),
        client_order_id=client_order_id,
    )


def claim_entry_permit(permit: EntrySubmissionPermit) -> None:
    """Consume one entry submission. A second claim commits nothing and sends nothing."""
    if not isinstance(permit, EntrySubmissionPermit) or not permit.owner_token:
        raise JournalUnavailable("entry_authority_refused")
    requested = _units(permit.requested_units, required=True)
    journal = active_journal()
    with journal._lock:
        journal._begin()
        try:
            cursor = journal._conn.execute(
                """
                UPDATE entry_operations
                   SET network_permit = 1,
                       submission_state = 'SENT',
                       updated_at = ?
                 WHERE operation_id = ?
                   AND owner_token = ?
                   AND account_binding = ?
                   AND instrument = ?
                   AND direction = ?
                   AND requested_units = ?
                   AND position_instance_id = ?
                   AND position_generation = ?
                   AND client_order_id = ?
                   AND submission_intent = 1
                   AND network_permit = 0
                   AND outcome = ?
                """,
                (
                    _now(),
                    permit.operation_id,
                    permit.owner_token,
                    permit.account_binding,
                    permit.instrument,
                    permit.direction,
                    requested,
                    permit.position_instance_id,
                    int(permit.position_generation),
                    permit.client_order_id,
                    ENTRY_SUBMITTING,
                ),
            )
            if cursor.rowcount != 1:
                journal._rollback()
                raise JournalUnavailable("entry_authority_refused")
            journal._commit()
        except JournalUnavailable:
            raise
        except Exception as exc:
            journal._rollback()
            raise JournalUnavailable("journal_lock_or_disk") from exc


def entry_row(operation_id: str) -> dict[str, Any] | None:
    journal = active_journal()
    row = journal._conn.execute(
        "SELECT * FROM entry_operations WHERE operation_id = ?",
        (operation_id,),
    ).fetchone()
    return dict(row) if row is not None else None


def mark_entry(
    operation_id: str,
    *,
    outcome: str,
    error: str,
    broker_order_id: str = "",
    broker_trade_id: str = "",
    transaction_ids: tuple[str, ...] = (),
    recovery_status: str = "",
) -> None:
    journal = active_journal()
    with journal._lock:
        journal._begin()
        try:
            cursor = journal._conn.execute(
                """
                UPDATE entry_operations
                   SET outcome = ?,
                       error_classification = ?,
                       broker_order_id = ?,
                       broker_trade_id = ?,
                       transaction_ids = ?,
                       recovery_status = CASE WHEN ? = '' THEN recovery_status ELSE ? END,
                       updated_at = ?
                 WHERE operation_id = ?
                """,
                (
                    outcome,
                    error,
                    broker_order_id or None,
                    broker_trade_id or None,
                    ",".join(transaction_ids),
                    recovery_status,
                    recovery_status,
                    _now(),
                    operation_id,
                ),
            )
            if cursor.rowcount != 1:
                journal._rollback()
                raise JournalUnavailable("operation_missing")
            journal._commit()
        except JournalUnavailable:
            raise
        except Exception as exc:
            journal._rollback()
            raise JournalUnavailable("persistence_failure") from exc


def recover_entry_operations() -> list[dict[str, Any]]:
    """Ambiguous submitted entries stay blocked. This does not send another order."""
    journal = active_journal()
    with journal._lock:
        rows = [
            dict(row)
            for row in journal._conn.execute(
                "SELECT * FROM entry_operations WHERE outcome != ?",
                (ENTRY_FINALISED,),
            ).fetchall()
        ]
        recovered: list[dict[str, Any]] = []
        for row in rows:
            intent = int(row["submission_intent"])
            if intent == 0 and row["outcome"] == ENTRY_RESERVED:
                outcome = "ENTRY_RECONCILIATION_REQUIRED"
                error = "reserved_without_submission_intent"
            elif intent == 1 and row["outcome"] in _AMBIGUOUS_ON_RESTART:
                outcome = "ENTRY_OUTCOME_AMBIGUOUS"
                error = "crash_after_entry_submission_intent"
            else:
                continue
            journal._begin()
            journal._conn.execute(
                """
                UPDATE entry_operations
                   SET outcome = ?, error_classification = ?, recovery_status = ?, updated_at = ?
                 WHERE operation_id = ?
                """,
                (outcome, error, error, _now(), row["operation_id"]),
            )
            journal._commit()
            recovered.append(entry_row(row["operation_id"]) or row)
        return recovered


def unresolved_entry_for(account_binding_value: str, instrument: str) -> dict[str, Any] | None:
    journal = active_journal()
    row = journal._conn.execute(
        """
        SELECT * FROM entry_operations
         WHERE account_binding = ? AND instrument = ? AND outcome != ?
        """,
        (account_binding_value, instrument, ENTRY_FINALISED),
    ).fetchone()
    return dict(row) if row is not None else None
