"""Source switch for one future read-only session. It is off.

Changing REAL_SESSION_SOURCE_ENABLEMENT requires a separate written authorisation.
No environment variable or command-line switch can turn it on.
"""

from __future__ import annotations

REAL_SESSION_SOURCE_ENABLEMENT = False
OFFLINE_MODE = "OFFLINE_TEST"
REAL_MODE = "REAL_SESSION"


class GateRejected(Exception):
    def __init__(self, code: str) -> None:
        self.code = code
        super().__init__(code)


def assert_real_session() -> None:
    """Pass only after the source constant above is set true on purpose."""
    if REAL_SESSION_SOURCE_ENABLEMENT is not True:
        raise GateRejected("REAL_OANDA_SESSION_NOT_AUTHORISED")


def assert_runtime_authorisation(grant: object = None) -> None:
    """Second operator authorisation. A synthetic confirmation is not this grant.

    The source switch is checked first. No grant object is ever issued while that
    switch is off, and this function does not accept an environment value or a
    command-line flag.
    """
    assert_real_session()
    if grant is not _RUNTIME_GRANT:
        raise GateRejected("REAL_OANDA_SESSION_NOT_AUTHORISED")


def issue_runtime_authorisation(*_args: object, **_kwargs: object) -> None:
    """Would return the runtime grant after the source switch is on. It is not issued now."""
    assert_real_session()


def open_real_session(*_args: object, **_kwargs: object) -> None:
    assert_real_session()
    assert_runtime_authorisation(None)


_RUNTIME_GRANT = object()
