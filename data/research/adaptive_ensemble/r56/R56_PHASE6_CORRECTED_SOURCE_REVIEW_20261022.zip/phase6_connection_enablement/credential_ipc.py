"""One-session credential frame on an anonymous pipe. Nothing is written to disk."""

from __future__ import annotations

import json
from typing import Any

SCHEMA = "r56.phase6.ipc.1"
AUTH_SCHEMA = "r56.phase6.ipc.2"
AUTH_MODE = "AUTHENTICATED_HARNESS"
MAX_FRAME = 262144
_MESSAGE = frozenset(
    {
        "schema",
        "mode",
        "step",
        "prior",
        "session_id",
        "collected_at",
        "fixture",
        "status",
        "body_text",
        "fill",
        "stall",
        "ignore_seconds",
        "request_deadline",
        "tls_policy",
        "proxy_from_environment",
        "pricing_bid",
        "credential",
    }
)
_CREDENTIAL = frozenset({"classification", "account_selector", "marker"})
_AUTH_MESSAGE = frozenset(
    {
        "schema",
        "mode",
        "step",
        "prior",
        "session_id",
        "collected_at",
        "fixture",
        "credential",
    }
)
_AUTH_CREDENTIAL = frozenset({"account_id", "token"})


class IpcRejected(Exception):
    def __init__(self, code: str) -> None:
        self.code = code
        super().__init__(code)


def encode(message: dict[str, Any]) -> bytes:
    raw = json.dumps(message, separators=(",", ":"), sort_keys=True).encode("utf-8")
    if len(raw) > MAX_FRAME:
        raise IpcRejected("IPC_TOO_LARGE")
    return raw


def _parse(raw: bytes) -> dict[str, Any]:
    if len(raw) > MAX_FRAME:
        raise IpcRejected("IPC_TOO_LARGE")
    try:
        text = raw.decode("utf-8")
    except UnicodeError:
        raise IpcRejected("IPC_REJECTED") from None
    try:
        message, end = json.JSONDecoder().raw_decode(text)
    except json.JSONDecodeError:
        raise IpcRejected("IPC_REJECTED") from None
    if text[end:].strip():
        raise IpcRejected("IPC_SECOND_FRAME")
    if not isinstance(message, dict):
        raise IpcRejected("IPC_REJECTED")
    return message


def consume(raw: bytes) -> tuple[dict[str, Any], str]:
    """Return the public job and a header. The marker is not retained in the job."""
    message = _parse(raw)
    if set(message) - _MESSAGE:
        raise IpcRejected("IPC_REJECTED")
    if message.get("schema") != SCHEMA:
        raise IpcRejected("IPC_REJECTED")
    if message.get("mode") != "OFFLINE_TEST":
        raise IpcRejected("REAL_OANDA_SESSION_NOT_AUTHORISED")
    credential = message.pop("credential", None)
    if not isinstance(credential, dict) or set(credential) != _CREDENTIAL:
        raise IpcRejected("REAL_CREDENTIAL_USE_NOT_AUTHORISED")
    marker = credential.get("marker")
    accepted = (
        credential.get("classification") == "SYNTHETIC_TEST_ONLY"
        and credential.get("account_selector") == "SYNTHETIC_PIN"
        and isinstance(marker, str)
        and marker.startswith("SYNTHETIC-")
        and "NOT-REAL" in marker
        and " " not in marker
        and "\n" not in marker
        and "\r" not in marker
    )
    del credential
    if not accepted or not isinstance(marker, str):
        raise IpcRejected("REAL_CREDENTIAL_USE_NOT_AUTHORISED")
    header = "Bearer " + marker
    del marker
    if "credential" in message or "marker" in message:
        raise IpcRejected("IPC_REJECTED")
    return message, header


def authenticated_frame(public: dict[str, Any], *, account_id: str, token: str) -> bytes:
    """Build one authenticated harness frame. The caller must not write it to disk."""
    message = {
        "schema": AUTH_SCHEMA,
        "mode": AUTH_MODE,
        "step": public.get("step"),
        "prior": public.get("prior"),
        "session_id": public.get("session_id"),
        "collected_at": public.get("collected_at"),
        "fixture": public.get("fixture"),
        "credential": {"account_id": account_id, "token": token},
    }
    return encode(message)


def consume_authenticated(raw: bytes) -> tuple[dict[str, Any], str, str]:
    """Accept one harness frame. Real-session mode is refused before any connection."""
    message = _parse(raw)
    if set(message) - _AUTH_MESSAGE:
        raise IpcRejected("IPC_REJECTED")
    for key in ("schema", "mode", "step", "prior", "session_id", "collected_at", "fixture", "credential"):
        if key not in message:
            raise IpcRejected("IPC_REJECTED")
    if message.get("schema") != AUTH_SCHEMA:
        raise IpcRejected("IPC_REJECTED")
    if message.get("mode") != AUTH_MODE:
        raise IpcRejected("REAL_OANDA_SESSION_NOT_AUTHORISED")
    if message.get("step") not in {"summary", "pricing"}:
        raise IpcRejected("IPC_REJECTED")
    prior = message.get("prior")
    if message["step"] == "summary" and prior != []:
        raise IpcRejected("IPC_REJECTED")
    if message["step"] == "pricing" and prior != ["summary"]:
        raise IpcRejected("IPC_REJECTED")
    if any(not isinstance(item, str) for item in prior):
        raise IpcRejected("IPC_REJECTED")
    credential = message.pop("credential", None)
    if not isinstance(credential, dict) or set(credential) != _AUTH_CREDENTIAL:
        raise IpcRejected("REAL_CREDENTIAL_USE_NOT_AUTHORISED")
    for value in credential.values():
        if isinstance(value, (dict, list)):
            raise IpcRejected("IPC_REJECTED")
    token = _synthetic_token(credential.get("token"))
    try:
        account_id = _transport().validate_authenticated_account(credential.get("account_id"))
    except Exception as exc:
        code = getattr(exc, "code", None)
        if code in {"ACCOUNT_ID_REJECTED", "SYNTHETIC_ACCOUNT_REJECTED"}:
            raise IpcRejected(code) from None
        raise IpcRejected("IPC_REJECTED") from None
    del credential
    header = "Bearer " + token
    del token
    if "credential" in message or "account_id" in message or "token" in message:
        raise IpcRejected("IPC_REJECTED")
    return message, header, account_id


def _synthetic_token(token: object) -> str:
    if (
        isinstance(token, str)
        and 16 <= len(token) <= 128
        and token.startswith("SYNTHETIC-")
        and "NOT-REAL" in token
        and not any(character in token for character in " \t\r\n/\\?#@:%")
        and not any(ord(character) < 32 or ord(character) == 127 for character in token)
    ):
        return token
    raise IpcRejected("REAL_CREDENTIAL_USE_NOT_AUTHORISED")


def _transport() -> Any:
    import importlib.util
    import sys
    from pathlib import Path

    name = "r56p6_restricted_live_transport"
    cached = sys.modules.get(name)
    if cached is not None:
        return cached
    path = Path(__file__).resolve().parent / "restricted_live_transport.py"
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    assert spec is not None and spec.loader is not None
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def contains_exact(text: str, secrets: tuple[str, ...]) -> bool:
    """True when the supplied secret, a bearer form, or an Authorization header is present."""
    if not isinstance(text, str):
        return True
    lowered = text.lower()
    if "bearer " in lowered or "authorization:" in lowered:
        return True
    for secret in secrets:
        if isinstance(secret, str) and len(secret) >= 4 and secret in text:
            return True
    return False


def redact_exact(text: str, secrets: tuple[str, ...]) -> str:
    """Replace each supplied secret with a fixed marker. The original text is not returned."""
    if not isinstance(text, str):
        return "REDACTED"
    redacted = text
    ordered = sorted((secret for secret in secrets if isinstance(secret, str) and len(secret) >= 4), key=len, reverse=True)
    for secret in ordered:
        if secret in redacted:
            redacted = redacted.replace(secret, "REDACTED")
    return redacted


def prompt_hidden_token(*_args: object, **_kwargs: object) -> None:
    """A future authorised edit would call getpass here. This phase does not."""
    raise IpcRejected("REAL_OANDA_SESSION_NOT_AUTHORISED")


def prompt_account_id(*_args: object, **_kwargs: object) -> None:
    raise IpcRejected("REAL_OANDA_SESSION_NOT_AUTHORISED")


def read_environment(*_args: object, **_kwargs: object) -> None:
    raise IpcRejected("REAL_CREDENTIAL_USE_NOT_AUTHORISED")


def read_dotenv(*_args: object, **_kwargs: object) -> None:
    raise IpcRejected("REAL_CREDENTIAL_USE_NOT_AUTHORISED")
