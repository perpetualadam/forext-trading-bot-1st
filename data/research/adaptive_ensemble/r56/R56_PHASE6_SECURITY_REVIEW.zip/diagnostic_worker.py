"""One supervised request. The child returns reduced diagnostics and closes its IPC pipe."""

from __future__ import annotations

import importlib.util
import json
import os
import sys
import time
from pathlib import Path
from typing import Any

HERE = Path(__file__).resolve().parent
PHASE2 = HERE.parent / "phase2_offline"
PHASE3 = HERE.parent / "phase3_offline"
PHASE5 = HERE.parent / "phase5_connection"
SCHEMA = "r56.phase6.child.1"
SUMMARY_PATTERN = "/v3/accounts/{accountID}/summary"
PRICING_PATTERN = "/v3/accounts/{accountID}/pricing"


def seal_network() -> None:
    import http.client
    import socket
    import ssl

    def blocked(*_args: Any, **_kwargs: Any) -> None:
        raise RuntimeError("NETWORK_SEALED")

    socket.socket = blocked  # type: ignore[misc, assignment]
    socket.create_connection = blocked  # type: ignore[assignment]
    socket.getaddrinfo = blocked  # type: ignore[assignment]
    ssl.SSLSocket = blocked  # type: ignore[misc, assignment]
    ssl.SSLContext.wrap_socket = blocked  # type: ignore[method-assign]
    http.client.HTTPConnection = blocked  # type: ignore[misc, assignment]
    http.client.HTTPSConnection = blocked  # type: ignore[misc, assignment]


def _load(directory: Path, prefix: str, stem: str) -> Any:
    name = f"{prefix}_{stem}"
    cached = sys.modules.get(name)
    if cached is not None:
        return cached
    spec = importlib.util.spec_from_file_location(name, directory / f"{stem}.py")
    module = importlib.util.module_from_spec(spec)
    assert spec is not None and spec.loader is not None
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def _fail(code: str, step: str = "none") -> dict[str, Any]:
    endpoint = SUMMARY_PATTERN if step == "summary" else PRICING_PATTERN if step == "pricing" else ""
    return {
        "schema_version": SCHEMA,
        "data_source": "SYNTHETIC_TEST_ONLY",
        "step": step,
        "result": "REJECTED" if step in {"summary", "pricing"} else "NOT_SENT",
        "endpoint": endpoint,
        "diagnostics": "NOT_PRODUCED",
        "error_code": code,
        "validation_warnings": [],
        "missing_evidence": [],
        "executable_order": "NOT_PRODUCED",
        "ipc_closed": True,
        "authorization_accepted": False,
    }


def run_job(job: dict[str, Any], header: str, *, child_process: bool, ipc_closed: bool) -> dict[str, Any]:
    seal_network()
    stall = job.get("stall")
    step = job.get("step")
    if stall == "dns":
        import socket

        try:
            socket.getaddrinfo("api-fxtrade.oanda.com", 443)
        except RuntimeError:
            return _fail("NETWORK_SEALED", step if step in {"summary", "pricing"} else "none")
        return _fail("NETWORK_SEAL_FAILED", step if step in {"summary", "pricing"} else "none")
    if step not in {"summary", "pricing"}:
        return _fail("STEP_REJECTED")
    if stall in {"hang", "ignore", "crash"} and not child_process:
        return _fail("STALL_REQUIRES_CHILD", step)
    if stall == "hang":
        time.sleep(30)
    elif stall == "ignore":
        time.sleep(float(job.get("ignore_seconds") or 10))
    elif stall == "crash":
        os._exit(3)
    try:
        if stall == "raise":
            raise RuntimeError(header)
        result = _step(job, step, header)
    except Exception:
        result = _fail("EXCEPTION_CONTAINED", step)
        result["validation_warnings"] = ["exception_contained"]
    finally:
        header = ""
    result["ipc_closed"] = ipc_closed
    return result


def _step(job: dict[str, Any], step: str, header: str) -> dict[str, Any]:
    transport_mod = _load(HERE, "r56p6", "restricted_live_transport")
    plan = _load(PHASE3, "r56p3", "readonly_request_plan")
    gate = _load(PHASE3, "r56p3", "readonly_request_gate")
    session_id = job.get("session_id")
    collected = job.get("collected_at")
    if not isinstance(session_id, str) or not session_id.startswith("r56-") or len(session_id) != 36:
        return _fail("SESSION_ID_REJECTED", step)
    if not isinstance(collected, str) or len(collected) > 40:
        return _fail("COLLECTED_AT_REJECTED", step)
    document = _fixture(job, step)
    body_text = job.get("body_text")
    body = body_text.encode("utf-8") if isinstance(body_text, str) else None
    exchange = transport_mod.FakeExchange(
        document,
        status_code=int(job.get("status") or 200),
        body=body,
        fill=int(job.get("fill") or 0),
        tls_policy=job.get("tls_policy") if isinstance(job.get("tls_policy"), dict) else None,
        proxy_from_environment=job.get("proxy_from_environment") is True,
    )
    transport = transport_mod.RestrictedLiveTransport(exchange)
    try:
        if step == "summary":
            gate.approve(plan.summary_candidate(), step=1, prior=[])
            if job.get("prior") not in ([], None):
                return _fail("SEQUENCE_REJECTED", step)
            raw = transport.get_account_summary(transport_mod.SELECTOR, authorization_header=header)
        else:
            gate.approve(plan.pricing_candidate(), step=2, prior=["summary"])
            if job.get("prior") != ["summary"]:
                return _fail("SEQUENCE_REJECTED", step)
            raw = transport.get_pricing(transport_mod.SELECTOR, authorization_header=header, prior=("summary",))
    except gate.GateRejected as exc:
        return _fail(exc.code, step)
    except transport_mod.TransportRejected as exc:
        failed = _fail(exc.code, step)
        failed["authorization_accepted"] = exchange.authorization_accepted
        return failed
    try:
        parsed = json.loads(raw.decode("utf-8"))
    except (UnicodeError, json.JSONDecodeError):
        return _fail("MALFORMED_JSON", step)
    stamped = _stamp(step, parsed, session_id, collected)
    if isinstance(stamped, dict) and stamped.get("outcome") != "DIAGNOSTIC_RECORDED":
        failed = _fail("SUMMARY_REJECTED", step)
        failed["diagnostics"] = stamped
        return failed
    if isinstance(stamped, list) and (not stamped or any(item.get("outcome") != "DIAGNOSTIC_RECORDED" for item in stamped)):
        failed = _fail("PRICING_REJECTED", step)
        failed["diagnostics"] = stamped
        return failed
    warnings: list[str] = []
    missing: list[str] = []
    rows = [stamped] if isinstance(stamped, dict) else stamped
    for item in rows:
        warnings.extend(item.get("validation_warnings") or [])
        missing.extend(item.get("missing_evidence") or [])
    return {
        "schema_version": SCHEMA,
        "data_source": "SYNTHETIC_TEST_ONLY",
        "step": step,
        "result": "SYNTHETIC_RESPONSE_ACCEPTED",
        "endpoint": SUMMARY_PATTERN if step == "summary" else PRICING_PATTERN,
        "diagnostics": stamped,
        "error_code": "NONE",
        "validation_warnings": _unique(warnings),
        "missing_evidence": _unique(missing),
        "executable_order": "NOT_PRODUCED",
        "ipc_closed": True,
        "authorization_accepted": exchange.authorization_accepted,
    }


def _fixture(job: dict[str, Any], step: str) -> dict[str, Any]:
    fixtures = _load(PHASE5, "r56p5fix", "synthetic_fixtures")
    name = job.get("fixture")
    if step == "summary":
        if name not in {None, "summary", "summary_no_currency"}:
            raise ValueError("fixture")
        return fixtures.summary_document(include_currency=name != "summary_no_currency")
    if name not in {None, "pricing", "pricing_no_bid"}:
        raise ValueError("fixture")
    bid = job.get("pricing_bid")
    return fixtures.pricing_document(include_bid=name != "pricing_no_bid", bid=bid if isinstance(bid, str) else "1.10000")


def _stamp(step: str, document: Any, session_id: str, collected: str) -> Any:
    writer = _load(PHASE2, "r56p2", "diagnostic_writer")
    if step == "summary":
        account_mod = _load(PHASE2, "r56p2", "account_diagnostics")
        body, _secrets = account_mod.build(json.loads(json.dumps(document)))
        return writer.stamp(body, data_source="SYNTHETIC_TEST_ONLY", session_id=session_id, collected_at=collected)
    pricing_mod = _load(PHASE2, "r56p2", "pricing_diagnostics")
    bodies, _secrets = pricing_mod.build(json.loads(json.dumps(document)))
    return [writer.stamp(body, data_source="SYNTHETIC_TEST_ONLY", session_id=session_id, collected_at=collected) for body in bodies]


def _unique(items: list[str]) -> list[str]:
    seen: list[str] = []
    for item in items:
        if item not in seen:
            seen.append(item)
    return seen


def _emit(payload: dict[str, Any]) -> None:
    sys.stdout.write(json.dumps(payload))


def main(argv: list[str]) -> int:
    if argv != ["--offline-worker"]:
        return 2
    seal_network()
    ipc = _load(HERE, "r56p6", "credential_ipc")
    try:
        raw = sys.stdin.buffer.read(ipc.MAX_FRAME + 1)
        sys.stdin.close()
        public, header = ipc.consume(raw)
    except Exception:
        _emit(_fail("IPC_REJECTED" if not isinstance(sys.exc_info()[1], ipc.IpcRejected) else sys.exc_info()[1].code))
        return 1
    if public.get("stall") == "malformed":
        sys.stdout.write("{")
        return 0
    if public.get("stall") == "leak":
        pins = _load(PHASE5, "r56p5", "restricted_https_transport")
        sys.stdout.write(json.dumps({"account_id": pins.SYNTHETIC_ACCOUNT_ID, "authorization": header}))
        return 0
    try:
        result = run_job(public, header, child_process=True, ipc_closed=sys.stdin.closed)
    except Exception:
        result = _fail("EXCEPTION_CONTAINED")
    finally:
        header = ""
    _emit(result)
    return 0 if result.get("error_code") == "NONE" else 1


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
