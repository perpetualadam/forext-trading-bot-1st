"""Source switch for one future read-only session. It is off.

Changing REAL_SESSION_SOURCE_ENABLEMENT requires a separate written authorisation.
No environment variable or command-line switch can turn it on.
"""

from __future__ import annotations

REAL_SESSION_SOURCE_ENABLEMENT = False
OFFLINE_MODE = "OFFLINE_TEST"
REAL_MODE = "REAL_SESSION"


class GateRejected(Exception):
    def __init__(self, code: str) -> None:
        self.code = code
        super().__init__(code)


def assert_real_session() -> None:
    """Pass only after the source constant above is set true on purpose."""
    if REAL_SESSION_SOURCE_ENABLEMENT is not True:
        raise GateRejected("REAL_OANDA_SESSION_NOT_AUTHORISED")


def open_real_session(*_args: object, **_kwargs: object) -> None:
    assert_real_session()
