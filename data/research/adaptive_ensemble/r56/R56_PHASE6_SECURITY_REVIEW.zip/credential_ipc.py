"""One-session credential frame on an anonymous pipe. Nothing is written to disk."""

from __future__ import annotations

import json
from typing import Any

SCHEMA = "r56.phase6.ipc.1"
MAX_FRAME = 262144
_MESSAGE = frozenset(
    {
        "schema",
        "mode",
        "step",
        "prior",
        "session_id",
        "collected_at",
        "fixture",
        "status",
        "body_text",
        "fill",
        "stall",
        "ignore_seconds",
        "request_deadline",
        "tls_policy",
        "proxy_from_environment",
        "pricing_bid",
        "credential",
    }
)
_CREDENTIAL = frozenset({"classification", "account_selector", "marker"})


class IpcRejected(Exception):
    def __init__(self, code: str) -> None:
        self.code = code
        super().__init__(code)


def encode(message: dict[str, Any]) -> bytes:
    raw = json.dumps(message, separators=(",", ":"), sort_keys=True).encode("utf-8")
    if len(raw) > MAX_FRAME:
        raise IpcRejected("IPC_TOO_LARGE")
    return raw


def consume(raw: bytes) -> tuple[dict[str, Any], str]:
    """Return the public job and a header. The marker is not retained in the job."""
    if len(raw) > MAX_FRAME:
        raise IpcRejected("IPC_TOO_LARGE")
    try:
        message = json.loads(raw.decode("utf-8"))
    except (UnicodeError, json.JSONDecodeError):
        raise IpcRejected("IPC_REJECTED") from None
    if not isinstance(message, dict) or set(message) - _MESSAGE:
        raise IpcRejected("IPC_REJECTED")
    if message.get("schema") != SCHEMA:
        raise IpcRejected("IPC_REJECTED")
    if message.get("mode") != "OFFLINE_TEST":
        raise IpcRejected("REAL_OANDA_SESSION_NOT_AUTHORISED")
    credential = message.pop("credential", None)
    if not isinstance(credential, dict) or set(credential) != _CREDENTIAL:
        raise IpcRejected("REAL_CREDENTIAL_USE_NOT_AUTHORISED")
    marker = credential.get("marker")
    accepted = (
        credential.get("classification") == "SYNTHETIC_TEST_ONLY"
        and credential.get("account_selector") == "SYNTHETIC_PIN"
        and isinstance(marker, str)
        and marker.startswith("SYNTHETIC-")
        and "NOT-REAL" in marker
        and " " not in marker
        and "\n" not in marker
        and "\r" not in marker
    )
    del credential
    if not accepted or not isinstance(marker, str):
        raise IpcRejected("REAL_CREDENTIAL_USE_NOT_AUTHORISED")
    header = "Bearer " + marker
    del marker
    if "credential" in message or "marker" in message:
        raise IpcRejected("IPC_REJECTED")
    return message, header


def prompt_hidden_token(*_args: object, **_kwargs: object) -> None:
    """A future authorised edit would call getpass here. This phase does not."""
    raise IpcRejected("REAL_OANDA_SESSION_NOT_AUTHORISED")


def prompt_account_id(*_args: object, **_kwargs: object) -> None:
    raise IpcRejected("REAL_OANDA_SESSION_NOT_AUTHORISED")


def read_environment(*_args: object, **_kwargs: object) -> None:
    raise IpcRejected("REAL_CREDENTIAL_USE_NOT_AUTHORISED")


def read_dotenv(*_args: object, **_kwargs: object) -> None:
    raise IpcRejected("REAL_CREDENTIAL_USE_NOT_AUTHORISED")
