"""Two GET methods. The live opener cannot run while the source switch is off."""

from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path
from typing import Any

HERE = Path(__file__).resolve().parent
PHASE5 = HERE.parent / "phase5_connection"
SELECTOR = "SYNTHETIC_PIN"
MAX_BODY_BYTES = 1048576
_REDIRECTS = frozenset({301, 302, 303, 307, 308})
_CHANGING = ("/orders", "/trades", "/positions", "/transactions", "/candles", "/financing", "/configuration")


class TransportRejected(Exception):
    def __init__(self, code: str) -> None:
        self.code = code
        super().__init__(code)


class PreparedGet:
    def __init__(self, *, kind: str, path: str, query: dict[str, str]) -> None:
        pins = _pins()
        self.method = "GET"
        self.scheme = "https"
        self.host = pins.HOST
        self.port = pins.PORT
        self.kind = kind
        self.path = path
        self.query = dict(query)
        self.body = None
        self.redirects = False
        self.retries = 0
        self.stream = False
        self.cookies = None


def _load(directory: Path, prefix: str, stem: str) -> Any:
    name = f"{prefix}_{stem}"
    cached = sys.modules.get(name)
    if cached is not None:
        return cached
    spec = importlib.util.spec_from_file_location(name, directory / f"{stem}.py")
    module = importlib.util.module_from_spec(spec)
    assert spec is not None and spec.loader is not None
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def _pins() -> Any:
    return _load(PHASE5, "r56p5", "restricted_https_transport")


def _gate() -> Any:
    return _load(HERE, "r56p6", "live_session_gate")


def _path(kind: str, account_selector: str) -> str:
    if account_selector != SELECTOR:
        raise TransportRejected("REAL_ACCOUNT_ID_REJECTED")
    pinned = _pins().SYNTHETIC_ACCOUNT_ID
    if not isinstance(pinned, str) or "/" in pinned or "\\" in pinned or ".." in pinned:
        raise TransportRejected("ACCOUNT_ID_REJECTED")
    tail = "summary" if kind == "summary" else "pricing"
    return "/v3/accounts/" + pinned + "/" + tail


def build_tls_context() -> Any:
    import ssl

    context = ssl.create_default_context(purpose=ssl.Purpose.SERVER_AUTH)
    if context.verify_mode != ssl.CERT_REQUIRED or context.check_hostname is not True:
        raise TransportRejected("TLS_VERIFICATION_REQUIRED")
    return context


def disable_tls_verification(*_args: Any, **_kwargs: Any) -> None:
    raise TransportRejected("TLS_VERIFICATION_CANNOT_BE_DISABLED")


def live_request_headers(authorization_header: str) -> dict[str, str]:
    if not isinstance(authorization_header, str) or not authorization_header.startswith("Bearer "):
        raise TransportRejected("AUTHORIZATION_REJECTED")
    return {"Accept": "application/json", "Authorization": authorization_header}


def validate_outbound(request: Any) -> None:
    pins = _pins()
    if not isinstance(request, PreparedGet):
        raise TransportRejected("REQUEST_REJECTED")
    if request.method != "GET":
        raise TransportRejected("METHOD_REJECTED")
    if request.scheme != "https":
        raise TransportRejected("SCHEME_REJECTED")
    if request.host != pins.HOST or request.port != pins.PORT:
        raise TransportRejected("HOST_REJECTED")
    path = str(request.path or "")
    lowered = path.lower()
    if "://" in path or path.startswith("//"):
        raise TransportRejected("URL_REJECTED")
    if any(piece in lowered for piece in _CHANGING) or "/instruments" in lowered or "stream" in lowered:
        raise TransportRejected("ACCOUNT_CHANGING_REJECTED")
    if request.kind == "summary":
        if path != _path("summary", SELECTOR) or request.query != {}:
            raise TransportRejected("QUERY_REJECTED" if request.query else "ENDPOINT_REJECTED")
    elif request.kind == "pricing":
        if path != _path("pricing", SELECTOR):
            raise TransportRejected("ENDPOINT_REJECTED")
        if request.query != {"instruments": pins.INSTRUMENTS}:
            raise TransportRejected("QUERY_REJECTED")
    else:
        raise TransportRejected("ENDPOINT_REJECTED")
    if request.body is not None:
        raise TransportRejected("BODY_REJECTED")
    if request.redirects is not False:
        raise TransportRejected("REDIRECT_REJECTED")
    if request.retries != 0:
        raise TransportRejected("RETRY_REJECTED")
    if request.stream is not False:
        raise TransportRejected("STREAM_REJECTED")
    if request.cookies not in (None, {}):
        raise TransportRejected("COOKIES_REJECTED")


class FakeExchange:
    """Stands in for the TLS socket. It has the same exchange signature as the live opener."""

    offline_only = True
    marker = "R56P6_FAKE_HTTPS"

    def __init__(
        self,
        document: dict | None = None,
        *,
        status_code: int = 200,
        body: bytes | None = None,
        fill: int = 0,
        tls_policy: dict | None = None,
        proxy_from_environment: bool = False,
    ) -> None:
        self.document = {} if document is None else document
        self.status_code = int(status_code)
        self.body = body
        self.fill = int(fill)
        self.tls_policy = tls_policy or {"verify_mode": "CERT_REQUIRED", "check_hostname": True}
        self.proxy_from_environment = proxy_from_environment
        self.authorization_accepted = False
        self.calls: list[tuple[str, str]] = []

    def exchange(self, prepared: PreparedGet, authorization_header: str) -> bytes:
        self.authorization_accepted = (
            isinstance(authorization_header, str)
            and authorization_header.startswith("Bearer SYNTHETIC-")
            and "NOT-REAL" in authorization_header
        )
        if not self.authorization_accepted:
            raise TransportRejected("AUTHORIZATION_REJECTED")
        self.calls.append((prepared.method, prepared.path))
        if self.fill:
            return b"x" * self.fill
        if self.body is not None:
            return self.body
        return json.dumps(self.document).encode("utf-8")


class LiveExchange:
    """HTTPS GET through the standard library. Construction is refused while the gate is off."""

    offline_only = False

    def exchange(self, prepared: PreparedGet, authorization_header: str) -> bytes:
        _gate().assert_real_session()
        validate_outbound(prepared)
        context = build_tls_context()
        import http.client

        connection = http.client.HTTPSConnection(prepared.host, prepared.port, context=context, timeout=5)
        path = prepared.path
        if prepared.kind == "pricing":
            path = prepared.path + "?instruments=" + prepared.query["instruments"]
        connection.request("GET", path, body=None, headers=live_request_headers(authorization_header))
        response = connection.getresponse()
        status = int(response.status)
        if status in _REDIRECTS:
            connection.close()
            raise TransportRejected("REDIRECT_REJECTED")
        payload = response.read(MAX_BODY_BYTES + 1)
        connection.close()
        if status != 200:
            raise TransportRejected(f"HTTP_{status}")
        if len(payload) > MAX_BODY_BYTES:
            raise TransportRejected("RESPONSE_TOO_LARGE")
        return payload


class RestrictedLiveTransport:
    def __init__(self, exchange: Any) -> None:
        if isinstance(exchange, LiveExchange):
            _gate().assert_real_session()
        elif exchange.__class__ is not FakeExchange or exchange.offline_only is not True or exchange.marker != "R56P6_FAKE_HTTPS":
            raise TransportRejected("LIVE_EXCHANGE_NOT_AUTHORISED")
        self.exchange = exchange
        self.kinds: list[str] = []

    def get_account_summary(self, account_selector: str, *, authorization_header: str) -> bytes:
        if self.kinds:
            raise TransportRejected("SUMMARY_DUPLICATE_REJECTED" if "summary" in self.kinds else "REQUEST_LIMIT")
        self.kinds.append("summary")
        prepared = PreparedGet(kind="summary", path=_path("summary", account_selector), query={})
        return self._finish(prepared, authorization_header)

    def get_pricing(self, account_selector: str, *, authorization_header: str, prior: tuple[str, ...]) -> bytes:
        if prior != ("summary",) or self.kinds:
            raise TransportRejected("SEQUENCE_REJECTED" if prior != ("summary",) else "REQUEST_LIMIT")
        self.kinds.append("pricing")
        prepared = PreparedGet(
            kind="pricing",
            path=_path("pricing", account_selector),
            query={"instruments": _pins().INSTRUMENTS},
        )
        return self._finish(prepared, authorization_header)

    def _finish(self, prepared: PreparedGet, authorization_header: str) -> bytes:
        validate_outbound(prepared)
        policy = getattr(self.exchange, "tls_policy", {"verify_mode": "CERT_REQUIRED", "check_hostname": True})
        if not isinstance(policy, dict) or policy.get("verify_mode") != "CERT_REQUIRED" or policy.get("check_hostname") is not True:
            raise TransportRejected("TLS_VERIFICATION_REQUIRED")
        if policy.get("allow_insecure") is True:
            raise TransportRejected("TLS_VERIFICATION_CANNOT_BE_DISABLED")
        if getattr(self.exchange, "proxy_from_environment", False) is not False:
            raise TransportRejected("PROXY_REJECTED")
        raw = self.exchange.exchange(prepared, authorization_header)
        status = int(getattr(self.exchange, "status_code", 200))
        if status in _REDIRECTS:
            raise TransportRejected("REDIRECT_REJECTED")
        if status != 200:
            raise TransportRejected(f"HTTP_{status}")
        if not isinstance(raw, (bytes, bytearray)) or len(raw) > MAX_BODY_BYTES:
            raise TransportRejected("RESPONSE_TOO_LARGE")
        return bytes(raw)
