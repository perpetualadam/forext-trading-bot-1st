"""Parent for two supervised GET workers. The wall clock and the IPC pipe stay here."""

from __future__ import annotations

import importlib.util
import json
import os
import re
import subprocess
import sys
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

HERE = Path(__file__).resolve().parent
WORKER = HERE / "diagnostic_worker.py"
PHASE5 = HERE.parent / "phase5_connection"
LOG_DIR = HERE / "synthetic_logs"
COMPLETE = "SESSION_COMPLETE_SYNTHETIC"
INCOMPLETE = "SESSION_INCOMPLETE"
ACCOUNT_ID_RE = re.compile(r"\d{3}-\d{3}-\d{3,}-\d{3}")
_SAFE_ENV = ("SYSTEMROOT", "SYSTEMDRIVE", "WINDIR", "COMSPEC", "PATH", "PATHEXT", "TEMP", "TMP")
_REQUEST = frozenset({"sequence", "method", "scheme", "host", "port", "endpoint", "query", "result", "body", "redirects", "retries", "stream"})
_TOP = frozenset(
    {
        "schema_version",
        "collected_at",
        "data_source",
        "session_id",
        "target_environment",
        "live_network_access",
        "confirmation",
        "network_permitted",
        "real_session_source_enablement",
        "process_isolation",
        "per_request_deadline_seconds",
        "session_deadline_seconds",
        "child_termination",
        "child_alive",
        "children_started",
        "observed_wall_seconds",
        "ipc_write_closed",
        "ipc_child_closed",
        "summary_request",
        "pricing_request",
        "account_diagnostics",
        "pricing_diagnostics",
        "missing_evidence",
        "validation_warnings",
        "session_status",
        "error_code",
        "executable_order",
        "order_payload",
        "quote_freshness",
        "gbp_pip_value",
        "stake_to_unit_mapping",
        "financing",
        "pip_location",
        "executable_position_size",
        "strategy_profitability",
        "gbp_conversion_fallback",
        "home_conversion_request",
        "broker_evidence_complete",
        "raw_response_persisted",
        "phase2_adapters",
    }
)

LAST_ARGV: list[str] = []
LAST_PUBLIC: list[dict[str, Any]] = []
LAST_IPC_WRITE_CLOSED = False
LAST_PROC: subprocess.Popen[bytes] | None = None
LAST_CHILD_RESULTS: list[dict[str, Any]] = []


class SupervisorRejected(Exception):
    def __init__(self, code: str) -> None:
        self.code = code
        super().__init__(code)


class SessionBudget:
    def __init__(self) -> None:
        self.started = 0

    def reserve(self) -> None:
        if self.started >= 2:
            raise SupervisorRejected("REQUEST_LIMIT")
        self.started += 1


def _load(directory: Path, prefix: str, stem: str) -> Any:
    name = f"{prefix}_{stem}"
    cached = sys.modules.get(name)
    if cached is not None:
        return cached
    spec = importlib.util.spec_from_file_location(name, directory / f"{stem}.py")
    module = importlib.util.module_from_spec(spec)
    assert spec is not None and spec.loader is not None
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def child_env() -> dict[str, str]:
    env = {"PYTHONDONTWRITEBYTECODE": "1", "PYTHONUTF8": "1", "PYTHONIOENCODING": "utf-8"}
    for key in _SAFE_ENV:
        value = os.environ.get(key)
        if value:
            env[key] = value
    for banned in ("HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY", "http_proxy", "https_proxy"):
        env.pop(banned, None)
    return env


def child_argv() -> list[str]:
    return [sys.executable, "-B", str(WORKER), "--offline-worker"]


def authenticated_child_argv() -> list[str]:
    """Real worker entry plus the harness transport seam. The seam cannot open HTTPSConnection."""
    return [sys.executable, "-B", str(WORKER), "--authenticated-worker", "--harness-transport"]


def new_session_id() -> str:
    return "r56-" + uuid.uuid4().hex


def _marker(credential: object) -> str:
    credentials = _load(PHASE5, "r56p5", "credential_gate")
    if credential.__class__ is not credentials.SyntheticCredential:
        raise SupervisorRejected("REAL_CREDENTIAL_USE_NOT_AUTHORISED")
    if getattr(credential, "classification", None) != "SYNTHETIC_TEST_ONLY":
        raise SupervisorRejected("REAL_CREDENTIAL_USE_NOT_AUTHORISED")
    marker = getattr(credential, "token", "")
    account_id = getattr(credential, "account_id", "")
    if not isinstance(marker, str) or not marker.startswith("SYNTHETIC-") or "NOT-REAL" not in marker:
        raise SupervisorRejected("REAL_CREDENTIAL_USE_NOT_AUTHORISED")
    if account_id != credentials.SYNTHETIC_ACCOUNT_ID:
        raise SupervisorRejected("REAL_CREDENTIAL_USE_NOT_AUTHORISED")
    return marker


def run_offline(
    *,
    answer: str,
    credential: object,
    summary_fixture: str = "summary",
    pricing_fixture: str = "pricing",
    summary_status: int = 200,
    pricing_status: int = 200,
    summary_body_text: str | None = None,
    summary_fill: int = 0,
    pricing_bid: str | None = None,
    stall: str | None = None,
    stall_step: str = "summary",
    ignore_seconds: float = 10.0,
    request_deadline: float = 5.0,
    session_deadline: float = 15.0,
    tls_policy: dict | None = None,
    proxy_from_environment: bool = False,
    log_dir: Path | None = None,
    session_id: str | None = None,
    collected_at: str | None = None,
) -> dict[str, Any]:
    global LAST_PUBLIC
    confirmation = _load(PHASE5, "r56p5", "operator_confirmation")
    label = str(LOG_DIR if log_dir is None else log_dir)
    screen = confirmation.render_screen(log_destination=label)
    agreed = confirmation.confirm_synthetic(answer, screen=screen)
    if agreed.get("network_permitted") is not False:
        raise SupervisorRejected("NETWORK_PERMITTED_REJECTED")
    marker = _marker(credential)
    try:
        if request_deadline <= 0 or request_deadline > 5 or session_deadline <= 0 or session_deadline > 15:
            raise SupervisorRejected("DEADLINE_ABOVE_CAP")
        target = _log_dir(log_dir)
        session = session_id or new_session_id()
        collected = collected_at or _now()
        budget = SessionBudget()
        LAST_PUBLIC = []
        wall_start = time.monotonic()
        summary_payload = None
        pricing_payload = None
        error = "NONE"
        terminated = False
        alive = False
        ipc_write_closed = False
        ipc_child_closed = False
        try:
            summary_payload, summary_term, summary_alive, write_closed, child_closed = _spawn(
                step="summary",
                prior=[],
                fixture=summary_fixture,
                status=summary_status,
                body_text=summary_body_text,
                fill=summary_fill,
                stall=stall if stall_step == "summary" else None,
                ignore_seconds=ignore_seconds,
                request_deadline=request_deadline,
                session_deadline=session_deadline,
                session_started=wall_start,
                session_id=session,
                collected_at=collected,
                marker=marker,
                budget=budget,
                tls_policy=tls_policy,
                proxy_from_environment=proxy_from_environment,
                pricing_bid=None,
            )
            terminated = summary_term
            alive = summary_alive
            ipc_write_closed = write_closed
            ipc_child_closed = child_closed
            if summary_term:
                error = "CHILD_TERMINATED"
            elif summary_payload is None:
                error = "CHILD_CRASHED"
            elif summary_payload.get("error_code") != "NONE":
                error = str(summary_payload["error_code"])
            elif not isinstance(summary_payload.get("diagnostics"), dict) or summary_payload["diagnostics"].get("outcome") != "DIAGNOSTIC_RECORDED":
                error = "SUMMARY_REJECTED"
            else:
                pricing_payload, pricing_term, pricing_alive, write_closed, child_closed = _spawn(
                    step="pricing",
                    prior=["summary"],
                    fixture=pricing_fixture,
                    status=pricing_status,
                    body_text=None,
                    fill=0,
                    stall=stall if stall_step == "pricing" else None,
                    ignore_seconds=ignore_seconds,
                    request_deadline=request_deadline,
                    session_deadline=session_deadline,
                    session_started=wall_start,
                    session_id=session,
                    collected_at=collected,
                    marker=marker,
                    budget=budget,
                    tls_policy=tls_policy,
                    proxy_from_environment=proxy_from_environment,
                    pricing_bid=pricing_bid,
                )
                terminated = pricing_term
                alive = pricing_alive
                ipc_write_closed = write_closed
                ipc_child_closed = child_closed and ipc_child_closed
                if pricing_term:
                    error = "CHILD_TERMINATED"
                elif pricing_payload is None:
                    error = "CHILD_CRASHED"
                elif pricing_payload.get("error_code") != "NONE":
                    error = str(pricing_payload["error_code"])
                elif not isinstance(pricing_payload.get("diagnostics"), list):
                    error = "PRICING_REJECTED"
        except SupervisorRejected as exc:
            error = exc.code
        record = _record(
            collected,
            session,
            summary_payload,
            pricing_payload,
            error=error,
            terminated=terminated,
            alive=alive,
            children=budget.started,
            elapsed=time.monotonic() - wall_start,
            request_deadline=request_deadline,
            session_deadline=session_deadline,
            ipc_write_closed=ipc_write_closed,
            ipc_child_closed=ipc_child_closed,
        )
        text = json.dumps(record, indent=2, sort_keys=True)
        exact = _exact_secrets(marker)
        if _sensitive(text, marker, exact) or (record["session_status"] == COMPLETE and record["error_code"] != "NONE"):
            record = _record(
                collected,
                session,
                None,
                None,
                error="SENSITIVE_OUTPUT_BLOCKED" if _sensitive(text, marker, exact) else "FALSE_SUCCESS_BLOCKED",
                terminated=terminated,
                alive=alive,
                children=budget.started,
                elapsed=time.monotonic() - wall_start,
                request_deadline=request_deadline,
                session_deadline=session_deadline,
                ipc_write_closed=ipc_write_closed,
                ipc_child_closed=False,
            )
            text = json.dumps(record, indent=2, sort_keys=True)
        path = _allocate(target, session)
        path.write_text(text + "\n", encoding="utf-8")
        return record
    finally:
        marker = ""


def _spawn(
    *,
    step: str,
    prior: list[str],
    fixture: str,
    status: int,
    body_text: str | None,
    fill: int,
    stall: str | None,
    ignore_seconds: float,
    request_deadline: float,
    session_deadline: float,
    session_started: float,
    session_id: str,
    collected_at: str,
    marker: str,
    budget: SessionBudget,
    tls_policy: dict | None,
    proxy_from_environment: bool,
    pricing_bid: str | None,
) -> tuple[dict[str, Any] | None, bool, bool, bool, bool]:
    global LAST_ARGV, LAST_IPC_WRITE_CLOSED, LAST_PROC
    remaining = session_deadline - (time.monotonic() - session_started)
    if remaining <= 0:
        raise SupervisorRejected("SESSION_DEADLINE")
    budget.reserve()
    public: dict[str, Any] = {
        "schema": "r56.phase6.ipc.1",
        "mode": "OFFLINE_TEST",
        "step": step,
        "prior": prior,
        "session_id": session_id,
        "collected_at": collected_at,
        "fixture": fixture,
        "status": status,
        "request_deadline": request_deadline,
    }
    if body_text is not None:
        public["body_text"] = body_text
    if fill:
        public["fill"] = fill
    if stall:
        public["stall"] = stall
        public["ignore_seconds"] = ignore_seconds
    if tls_policy is not None:
        public["tls_policy"] = tls_policy
    if proxy_from_environment:
        public["proxy_from_environment"] = True
    if pricing_bid is not None:
        public["pricing_bid"] = pricing_bid
    LAST_PUBLIC.append(public)
    ipc = _load(HERE, "r56p6", "credential_ipc")
    frame = ipc.encode(
        {
            **public,
            "credential": {
                "classification": "SYNTHETIC_TEST_ONLY",
                "account_selector": "SYNTHETIC_PIN",
                "marker": marker,
            },
        }
    )
    argv = child_argv()
    LAST_ARGV = argv
    proc = subprocess.Popen(
        argv,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=child_env(),
        cwd=str(HERE),
    )
    LAST_PROC = proc
    assert proc.stdin is not None
    proc.stdin.write(frame)
    proc.stdin.close()
    del frame
    write_closed = False
    try:
        proc.stdin.write(b"x")
    except (ValueError, OSError):
        write_closed = True
    LAST_IPC_WRITE_CLOSED = write_closed
    timeout = min(request_deadline, remaining)
    terminated = False
    try:
        out, err = proc.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        terminated = True
        proc.kill()
        out, err = proc.communicate()
    del err
    alive = proc.poll() is None
    if terminated:
        return None, True, alive, write_closed, False
    text = out.decode("utf-8", errors="replace")
    if _sensitive(text, marker, _exact_secrets(marker)):
        return _child_error("SENSITIVE_OUTPUT_BLOCKED", step), False, False, write_closed, False
    if not text.strip():
        code = "CHILD_CRASHED" if proc.returncode not in (0, None) else "MALFORMED_CHILD_RESULT"
        return _child_error(code, step), False, False, write_closed, False
    try:
        payload = json.loads(text)
    except json.JSONDecodeError:
        return _child_error("MALFORMED_CHILD_RESULT", step), False, False, write_closed, False
    if not isinstance(payload, dict) or payload.get("data_source") != "SYNTHETIC_TEST_ONLY":
        return _child_error("MALFORMED_CHILD_RESULT", step), False, False, write_closed, False
    if payload.get("step") != step or payload.get("executable_order") != "NOT_PRODUCED":
        return _child_error("MALFORMED_CHILD_RESULT", step), False, False, write_closed, False
    return payload, False, False, write_closed, payload.get("ipc_closed") is True


def _child_error(code: str, step: str) -> dict[str, Any]:
    endpoint = "/v3/accounts/{accountID}/summary" if step == "summary" else "/v3/accounts/{accountID}/pricing"
    return {
        "schema_version": "r56.phase6.child.1",
        "data_source": "SYNTHETIC_TEST_ONLY",
        "step": step,
        "result": "REJECTED",
        "endpoint": endpoint,
        "diagnostics": "NOT_PRODUCED",
        "error_code": code,
        "validation_warnings": [],
        "missing_evidence": [],
        "executable_order": "NOT_PRODUCED",
        "ipc_closed": False,
        "authorization_accepted": False,
    }


def _record(
    collected: str,
    session: str,
    summary_payload: dict[str, Any] | None,
    pricing_payload: dict[str, Any] | None,
    *,
    error: str,
    terminated: bool,
    alive: bool,
    children: int,
    elapsed: float,
    request_deadline: float,
    session_deadline: float,
    ipc_write_closed: bool,
    ipc_child_closed: bool,
) -> dict[str, Any]:
    pins = _load(PHASE5, "r56p5", "restricted_https_transport")
    gate = _load(HERE, "r56p6", "live_session_gate")
    account = summary_payload.get("diagnostics") if isinstance(summary_payload, dict) else "NOT_PRODUCED"
    pricing = pricing_payload.get("diagnostics") if isinstance(pricing_payload, dict) else "NOT_PRODUCED"
    if account is None:
        account = "NOT_PRODUCED"
    if pricing is None:
        pricing = "NOT_PRODUCED"
    warnings: list[str] = []
    for payload in (summary_payload, pricing_payload):
        if isinstance(payload, dict):
            warnings.extend(payload.get("validation_warnings") or [])
    missing = [
        "QUOTE_FRESHNESS_NOT_VERIFIED",
        "GBP_PIP_VALUE_UNVERIFIED",
        "STAKE_TO_UNIT_MAPPING_NOT_VERIFIED",
        "FINANCING_NOT_VERIFIED",
        "PIP_LOCATION_NOT_ESTABLISHED",
        "HOME_CONVERSION_NOT_VERIFIED",
    ]
    if isinstance(account, dict) and account.get("home_currency") == "ACCOUNT_HOME_CURRENCY_API_UNVERIFIED":
        missing.append("ACCOUNT_HOME_CURRENCY_API_UNVERIFIED")
    if alive:
        error = "CHILD_CLEANUP_FAILED"
    status = COMPLETE if error == "NONE" and terminated is False and alive is False else INCOMPLETE
    record = {
        "schema_version": "r56.phase6.1",
        "collected_at": collected,
        "data_source": "SYNTHETIC_TEST_ONLY",
        "session_id": session,
        "target_environment": pins.TARGET_ENVIRONMENT,
        "live_network_access": pins.LIVE_NETWORK_ACCESS,
        "confirmation": "CONFIRMED_SYNTHETIC",
        "network_permitted": False,
        "real_session_source_enablement": gate.REAL_SESSION_SOURCE_ENABLEMENT is True,
        "process_isolation": "CHILD_PROCESS",
        "per_request_deadline_seconds": request_deadline,
        "session_deadline_seconds": session_deadline,
        "child_termination": "TERMINATED" if terminated else "NOT_REQUIRED",
        "child_alive": bool(alive),
        "children_started": children,
        "observed_wall_seconds": f"{elapsed:.4f}",
        "ipc_write_closed": bool(ipc_write_closed),
        "ipc_child_closed": bool(ipc_child_closed),
        "summary_request": _request(1, pins.SUMMARY_PATTERN, {}, summary_payload),
        "pricing_request": _request(2, pins.PRICING_PATTERN, {"instruments": pins.INSTRUMENTS}, pricing_payload),
        "account_diagnostics": account,
        "pricing_diagnostics": pricing,
        "missing_evidence": missing,
        "validation_warnings": _unique(warnings),
        "session_status": status,
        "error_code": error,
        "executable_order": "NOT_PRODUCED",
        "order_payload": "NOT_PRODUCED",
        "quote_freshness": "QUOTE_FRESHNESS_NOT_VERIFIED",
        "gbp_pip_value": "GBP_PIP_VALUE_UNVERIFIED",
        "stake_to_unit_mapping": "STAKE_TO_UNIT_MAPPING_NOT_VERIFIED",
        "financing": "FINANCING_NOT_VERIFIED",
        "pip_location": "NOT_ESTABLISHED",
        "executable_position_size": "NOT_CALCULATED",
        "strategy_profitability": "NOT_ESTABLISHED",
        "gbp_conversion_fallback": "NOT_USED",
        "home_conversion_request": "NOT_REQUESTED",
        "broker_evidence_complete": False,
        "raw_response_persisted": False,
        "phase2_adapters": "REUSED",
    }
    if set(record) != _TOP:
        raise SupervisorRejected("ALLOWLIST_REJECTED")
    return record


def _request(sequence: int, endpoint: str, query: dict, payload: dict[str, Any] | None) -> dict[str, Any]:
    result = "NOT_SENT"
    if isinstance(payload, dict):
        result = str(payload.get("result") or "REJECTED")
    row = {
        "sequence": sequence,
        "method": "GET",
        "scheme": "https",
        "host": "api-fxtrade.oanda.com",
        "port": 443,
        "endpoint": endpoint,
        "query": query,
        "result": result,
        "body": "NONE",
        "redirects": False,
        "retries": 0,
        "stream": False,
    }
    if set(row) != _REQUEST:
        raise SupervisorRejected("ALLOWLIST_REJECTED")
    return row


def _exact_secrets(marker: str) -> tuple[str, ...]:
    pins = _load(PHASE5, "r56p5", "restricted_https_transport")
    values: list[str] = []
    if isinstance(marker, str) and marker:
        values.extend((marker, "Bearer " + marker, "Authorization: Bearer " + marker))
    pin = getattr(pins, "SYNTHETIC_ACCOUNT_ID", "")
    if isinstance(pin, str) and pin:
        values.append(pin)
    return tuple(values)


def _sensitive(text: str, marker: str, exact: tuple[str, ...] = ()) -> bool:
    ipc = _load(HERE, "r56p6", "credential_ipc")
    if ipc.contains_exact(text, (marker, *exact)):
        return True
    if ACCOUNT_ID_RE.search(text):
        return True
    return False


def _log_dir(path: Path | None) -> Path:
    target = LOG_DIR if path is None else Path(path)
    resolved = target.resolve()
    try:
        resolved.relative_to(HERE.resolve() / "synthetic_logs")
    except ValueError:
        raise SupervisorRejected("LOG_PATH_OUTSIDE") from None
    resolved.mkdir(parents=True, exist_ok=True)
    return resolved


def _allocate(log_dir: Path, session_id: str) -> Path:
    token = session_id.replace("-", "")
    for number in range(1, 10000):
        path = log_dir / f"r56-phase6-{token}-{number:04d}.json"
        try:
            handle = path.open("x", encoding="utf-8")
        except FileExistsError:
            continue
        handle.close()
        return path
    raise SupervisorRejected("LOG_NAME_EXHAUSTED")


def _unique(items: list[str]) -> list[str]:
    seen: list[str] = []
    for item in items:
        if item not in seen:
            seen.append(item)
    return seen


def _now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def prepare_real_session(*args: object, **kwargs: object) -> None:
    gate = _load(HERE, "r56p6", "live_session_gate")
    gate.prepare_real_session(*args, **kwargs)


def _authorisation(session_id: str, step: str) -> dict[str, Any]:
    gate = _load(HERE, "r56p6", "live_session_gate")
    return {
        "kind": "HARNESS_SESSION",
        "session_id": session_id,
        "step": step,
        "host": gate.LIVE_HOST,
        "port": gate.LIVE_PORT,
        "plan_id": gate.PLAN_ID,
        "confirmation": gate.ONE_SESSION_PHRASE,
    }


def _spawn_authenticated(
    *,
    step: str,
    prior: list[str],
    fixture: str,
    status: int,
    stall: str | None,
    ignore_seconds: float,
    request_deadline: float,
    session_deadline: float,
    session_started: float,
    session_id: str,
    collected_at: str,
    account_id: str,
    token: str,
    budget: SessionBudget,
) -> tuple[dict[str, Any] | None, bool, bool, bool, bool]:
    global LAST_ARGV, LAST_IPC_WRITE_CLOSED, LAST_PROC, LAST_PUBLIC, LAST_CHILD_RESULTS
    remaining = session_deadline - (time.monotonic() - session_started)
    if remaining <= 0:
        raise SupervisorRejected("SESSION_DEADLINE")
    budget.reserve()
    public = {
        "schema": "r56.phase6.ipc.2",
        "mode": "AUTHENTICATED_HARNESS",
        "step": step,
        "prior": prior,
        "session_id": session_id,
        "collected_at": collected_at,
        "fixture": fixture,
    }
    LAST_PUBLIC.append(dict(public))
    ipc = _load(HERE, "r56p6", "credential_ipc")
    frame = ipc.authenticated_frame(
        public,
        account_id=account_id,
        token=token,
        authorisation=_authorisation(session_id, step),
        status=status,
        stall=stall,
        ignore_seconds=ignore_seconds if stall else None,
    )
    argv = authenticated_child_argv()
    LAST_ARGV = argv
    proc = subprocess.Popen(
        argv,
        stdin=subprocess.PIPE,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        env=child_env(),
        cwd=str(HERE),
    )
    LAST_PROC = proc
    assert proc.stdin is not None
    proc.stdin.write(frame)
    proc.stdin.close()
    del frame
    write_closed = False
    try:
        proc.stdin.write(b"x")
    except (ValueError, OSError):
        write_closed = True
    LAST_IPC_WRITE_CLOSED = write_closed
    timeout = min(request_deadline, remaining)
    terminated = False
    try:
        out, err = proc.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        terminated = True
        proc.kill()
        out, err = proc.communicate()
    del err
    alive = proc.poll() is None
    if terminated:
        return None, True, alive, write_closed, False
    text = out.decode("utf-8", errors="replace")
    exact = _exact_secrets(token) + (account_id, "Bearer " + token, "Authorization: Bearer " + token)
    if _sensitive(text, token, exact):
        blocked = _child_error("SENSITIVE_OUTPUT_BLOCKED", step)
        LAST_CHILD_RESULTS.append(blocked)
        return blocked, False, False, write_closed, False
    if not text.strip():
        code = "CHILD_CRASHED" if proc.returncode not in (0, None) else "MALFORMED_CHILD_RESULT"
        return _child_error(code, step), False, False, write_closed, False
    try:
        payload = json.loads(text)
    except json.JSONDecodeError:
        return _child_error("MALFORMED_CHILD_RESULT", step), False, False, write_closed, False
    if not isinstance(payload, dict) or payload.get("data_source") != "SYNTHETIC_TEST_ONLY":
        return _child_error("MALFORMED_CHILD_RESULT", step), False, False, write_closed, False
    if payload.get("step") != step or payload.get("executable_order") != "NOT_PRODUCED":
        return _child_error("MALFORMED_CHILD_RESULT", step), False, False, write_closed, False
    LAST_CHILD_RESULTS.append(payload)
    return payload, False, False, write_closed, payload.get("ipc_closed") is True


def run_authenticated_harness_session(
    *,
    answer: str,
    credential_source: Any,
    summary_fixture: str = "summary",
    pricing_fixture: str = "pricing",
    summary_status: int = 200,
    pricing_status: int = 200,
    stall: str | None = None,
    stall_step: str = "summary",
    ignore_seconds: float = 10.0,
    request_deadline: float = 5.0,
    session_deadline: float = 15.0,
    log_dir: Path | None = None,
    session_id: str | None = None,
    collected_at: str | None = None,
    live: bool = False,
) -> dict[str, Any]:
    """Parent entry for the authenticated worker. live=True stops before credentials while the source switch is off."""
    global LAST_PUBLIC, LAST_CHILD_RESULTS
    gate = _load(HERE, "r56p6", "live_session_gate")
    if live:
        gate.assert_real_session()
    screen = gate.render_plan()
    confirmation = gate.confirm_one_session(answer, screen=screen)
    if confirmation.get("network_permitted") is not False or confirmation.get("real_session_source_enablement") is not False:
        raise SupervisorRejected("NETWORK_PERMITTED_REJECTED")
    try:
        gate.issue_runtime_authorisation()
    except gate.GateRejected as exc:
        if exc.code != "REAL_OANDA_SESSION_NOT_AUTHORISED":
            raise
    else:
        raise SupervisorRejected("REAL_GRANT_ISSUED")
    if request_deadline <= 0 or request_deadline > 5 or session_deadline <= 0 or session_deadline > 15:
        raise SupervisorRejected("DEADLINE_ABOVE_CAP")
    target = _log_dir(log_dir)
    account_id, token = credential_source()
    held_account, held_token = account_id, token
    transport = _load(HERE, "r56p6", "restricted_live_transport")
    transport.validate_authenticated_account(account_id)
    session = session_id or new_session_id()
    collected = collected_at or _now()
    budget = SessionBudget()
    LAST_PUBLIC = []
    LAST_CHILD_RESULTS = []
    wall_start = time.monotonic()
    summary_payload = None
    pricing_payload = None
    error = "NONE"
    terminated = False
    alive = False
    ipc_write_closed = False
    ipc_child_closed = False
    try:
        summary_payload, summary_term, summary_alive, write_closed, child_closed = _spawn_authenticated(
            step="summary",
            prior=[],
            fixture=summary_fixture,
            status=summary_status,
            stall=stall if stall_step == "summary" else None,
            ignore_seconds=ignore_seconds,
            request_deadline=request_deadline,
            session_deadline=session_deadline,
            session_started=wall_start,
            session_id=session,
            collected_at=collected,
            account_id=account_id,
            token=token,
            budget=budget,
        )
        terminated = summary_term
        alive = summary_alive
        ipc_write_closed = write_closed
        ipc_child_closed = child_closed
        if summary_term:
            error = "CHILD_TERMINATED"
        elif summary_payload is None:
            error = "CHILD_CRASHED"
        elif summary_payload.get("error_code") != "NONE":
            error = str(summary_payload["error_code"])
        elif not isinstance(summary_payload.get("diagnostics"), dict) or summary_payload["diagnostics"].get("outcome") != "DIAGNOSTIC_RECORDED":
            error = "SUMMARY_REJECTED"
        else:
            pricing_payload, pricing_term, pricing_alive, write_closed, child_closed = _spawn_authenticated(
                step="pricing",
                prior=["summary"],
                fixture=pricing_fixture,
                status=pricing_status,
                stall=stall if stall_step == "pricing" else None,
                ignore_seconds=ignore_seconds,
                request_deadline=request_deadline,
                session_deadline=session_deadline,
                session_started=wall_start,
                session_id=session,
                collected_at=collected,
                account_id=account_id,
                token=token,
                budget=budget,
            )
            terminated = pricing_term
            alive = pricing_alive
            ipc_write_closed = write_closed
            ipc_child_closed = child_closed and ipc_child_closed
            if pricing_term:
                error = "CHILD_TERMINATED"
            elif pricing_payload is None:
                error = "CHILD_CRASHED"
            elif pricing_payload.get("error_code") != "NONE":
                error = str(pricing_payload["error_code"])
            elif not isinstance(pricing_payload.get("diagnostics"), list):
                error = "PRICING_REJECTED"
    except SupervisorRejected as exc:
        error = exc.code
    record = _record(
        collected,
        session,
        summary_payload,
        pricing_payload,
        error=error,
        terminated=terminated,
        alive=alive,
        children=budget.started,
        elapsed=time.monotonic() - wall_start,
        request_deadline=request_deadline,
        session_deadline=session_deadline,
        ipc_write_closed=ipc_write_closed,
        ipc_child_closed=ipc_child_closed,
    )
    text = json.dumps(record, indent=2, sort_keys=True)
    exact = _exact_secrets(held_token) + (held_account, "Bearer " + held_token, "Authorization: Bearer " + held_token)
    if _sensitive(text, held_token, exact):
        record = _record(
            collected,
            session,
            None,
            None,
            error="SENSITIVE_OUTPUT_BLOCKED",
            terminated=terminated,
            alive=alive,
            children=budget.started,
            elapsed=time.monotonic() - wall_start,
            request_deadline=request_deadline,
            session_deadline=session_deadline,
            ipc_write_closed=ipc_write_closed,
            ipc_child_closed=False,
        )
        text = json.dumps(record, indent=2, sort_keys=True)
    held_account = ""
    held_token = ""
    path = _allocate(target, session)
    path.write_text(text + "\n", encoding="utf-8")
    return record
