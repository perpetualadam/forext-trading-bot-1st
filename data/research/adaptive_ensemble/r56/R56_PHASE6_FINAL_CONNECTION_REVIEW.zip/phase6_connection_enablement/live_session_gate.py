"""Source switch for one future read-only session. It is off.

Changing REAL_SESSION_SOURCE_ENABLEMENT requires a separate written authorisation.
No environment variable or command-line switch can turn it on.

A runtime grant is session-specific and step-specific. It is not a secret and it
is not server-side authorisation. It lives in process memory, is marked spent
when the session ends, and cannot be minted while the source switch is off.
A synthetic confirmation cannot mint it. A harness grant cannot open HTTPS.
"""

from __future__ import annotations

REAL_SESSION_SOURCE_ENABLEMENT = False
OFFLINE_MODE = "OFFLINE_TEST"
REAL_MODE = "REAL_SESSION"
PLAN_ID = "r56.phase6.two-get.1"
LIVE_HOST = "api-fxtrade.oanda.com"
LIVE_PORT = 443
ONE_SESSION_PHRASE = "CONFIRM ONE DIAGNOSTIC SESSION"
SYNTHETIC_PHRASE = "SYNTHETIC OFFLINE CONFIRM"


class GateRejected(Exception):
    def __init__(self, code: str) -> None:
        self.code = code
        super().__init__(code)


class RuntimeGrant:
    """Capability for the real HTTPS branch. issue_runtime_authorisation is the only constructor caller."""

    def __init__(self, session_id: str, step: str) -> None:
        self.session_id = session_id
        self.step = step
        self.plan_id = PLAN_ID
        self.host = LIVE_HOST
        self.spent = False
        self.authorises_network = True


class HarnessGrant:
    """Capability for an injected fake connection. It never authorises a socket."""

    def __init__(self, session_id: str, step: str) -> None:
        self.session_id = session_id
        self.step = step
        self.plan_id = PLAN_ID
        self.host = LIVE_HOST
        self.spent = False
        self.authorises_network = False


def assert_real_session() -> None:
    """Pass only after the source constant above is set true on purpose."""
    if REAL_SESSION_SOURCE_ENABLEMENT is not True:
        raise GateRejected("REAL_OANDA_SESSION_NOT_AUTHORISED")


def fixed_plan() -> dict[str, object]:
    return {
        "plan_id": PLAN_ID,
        "environment": "OANDA_LIVE",
        "host": LIVE_HOST,
        "port": LIVE_PORT,
        "requests": ["summary", "pricing"],
        "methods": ["GET", "GET"],
    }


def render_plan() -> str:
    return "\n".join(
        (
            "Environment OANDA LIVE",
            "Host api-fxtrade.oanda.com:443",
            "GET /v3/accounts/{accountID}/summary",
            "GET /v3/accounts/{accountID}/pricing?instruments=EUR_USD,GBP_USD,USD_JPY,AUD_USD,USD_CAD,USD_CHF",
            "No orders. No position changes. One diagnostic session.",
        )
    )


def _plan_ok(plan: object) -> bool:
    expected = fixed_plan()
    return isinstance(plan, dict) and plan == expected


def _session_ok(session_id: object, step: object) -> bool:
    return (
        isinstance(session_id, str)
        and session_id.startswith("r56-")
        and len(session_id) == 36
        and step in {"summary", "pricing"}
    )


def confirm_one_session(answer: object, *, screen: object) -> dict[str, object]:
    """Operator acknowledgement of the two-GET plan. This does not enable the network."""
    if answer == SYNTHETIC_PHRASE or answer != ONE_SESSION_PHRASE:
        raise GateRejected("CONFIRMATION_REJECTED")
    if not isinstance(screen, str) or LIVE_HOST not in screen or "summary" not in screen or "pricing" not in screen:
        raise GateRejected("CONFIRMATION_REJECTED")
    return {
        "confirmed": True,
        "network_permitted": False,
        "real_session_source_enablement": REAL_SESSION_SOURCE_ENABLEMENT is True,
    }


def issue_runtime_authorisation(*_args: object, **kwargs: object) -> RuntimeGrant:
    """Mint one real grant. Refuses while the source switch is off, before any other check."""
    assert_real_session()
    answer = kwargs.get("answer")
    if answer == SYNTHETIC_PHRASE or answer != ONE_SESSION_PHRASE:
        raise GateRejected("REAL_OANDA_SESSION_NOT_AUTHORISED")
    confirmation = kwargs.get("confirmation")
    if not isinstance(confirmation, dict) or confirmation.get("confirmed") is not True or confirmation.get("network_permitted") is not False:
        raise GateRejected("REAL_OANDA_SESSION_NOT_AUTHORISED")
    if not _plan_ok(kwargs.get("plan")) or not _session_ok(kwargs.get("session_id"), kwargs.get("step")):
        raise GateRejected("GRANT_REJECTED")
    return RuntimeGrant(str(kwargs["session_id"]), str(kwargs["step"]))


def assert_runtime_authorisation(grant: object = None, *, session_id: str | None = None, step: str | None = None) -> None:
    """Accept only an unspent real grant for this session and step."""
    assert_real_session()
    if grant is None or grant.__class__ is not RuntimeGrant:
        raise GateRejected("GRANT_REJECTED")
    if grant.spent:
        raise GateRejected("GRANT_EXPIRED")
    if grant.session_id != session_id or grant.step != step or grant.plan_id != PLAN_ID or grant.host != LIVE_HOST:
        raise GateRejected("GRANT_REJECTED")
    if grant.authorises_network is not True:
        raise GateRejected("GRANT_REJECTED")


def issue_harness_authorisation(*_args: object, **kwargs: object) -> HarnessGrant:
    """Mint a fake-connection grant. A synthetic phrase cannot mint it, and it cannot open a socket."""
    answer = kwargs.get("answer")
    if answer == SYNTHETIC_PHRASE or answer != ONE_SESSION_PHRASE:
        raise GateRejected("CONFIRMATION_REJECTED")
    confirmation = kwargs.get("confirmation")
    if not isinstance(confirmation, dict) or confirmation.get("confirmed") is not True or confirmation.get("network_permitted") is not False:
        raise GateRejected("CONFIRMATION_REJECTED")
    if confirmation.get("real_session_source_enablement") is not False:
        raise GateRejected("REAL_OANDA_SESSION_NOT_AUTHORISED")
    if not _plan_ok(kwargs.get("plan")) or not _session_ok(kwargs.get("session_id"), kwargs.get("step")):
        raise GateRejected("GRANT_REJECTED")
    return HarnessGrant(str(kwargs["session_id"]), str(kwargs["step"]))


def assert_harness_authorisation(grant: object = None, *, session_id: str | None = None, step: str | None = None) -> None:
    if grant is None or grant.__class__ is not HarnessGrant:
        raise GateRejected("GRANT_REJECTED")
    if grant.authorises_network is not False:
        raise GateRejected("GRANT_REJECTED")
    if grant.spent:
        raise GateRejected("GRANT_EXPIRED")
    if grant.session_id != session_id or grant.step != step or grant.plan_id != PLAN_ID or grant.host != LIVE_HOST:
        raise GateRejected("GRANT_REJECTED")


def expire_grant(grant: object) -> None:
    if isinstance(grant, (RuntimeGrant, HarnessGrant)):
        grant.spent = True


def open_real_session(*_args: object, **_kwargs: object) -> None:
    assert_real_session()
    assert_runtime_authorisation(None)


def prepare_real_session(*_args: object, **kwargs: object) -> None:
    """Prompt order after both gates. The source switch rejects this before any prompt."""
    assert_real_session()
    import importlib.util
    import sys
    from pathlib import Path

    name = "r56p6_credential_ipc"
    module = sys.modules.get(name)
    if module is None:
        path = Path(__file__).resolve().parent / "credential_ipc.py"
        spec = importlib.util.spec_from_file_location(name, path)
        module = importlib.util.module_from_spec(spec)
        assert spec is not None and spec.loader is not None
        sys.modules[name] = module
        spec.loader.exec_module(module)
    module.prompt_account_id(**kwargs)
    module.prompt_hidden_token(**kwargs)
